import os
import re
import pathlib
import logging
import shutil
import label_studio_sdk
import dotenv


dotenv.load_dotenv(override=True)
model=None
tokenizer=None
# dotenv.load_dotenv() 

import torch
from typing import List, Dict, Optional
from label_studio_ml.model import LabelStudioMLBase
from label_studio_ml.response import ModelResponse

from transformers import AutoTokenizer, AutoModelForCausalLM

logger = logging.getLogger(__name__)

class EntityExtractionModel(LabelStudioMLBase):
    """Name Entity Recognition Interactive Model
    """
    LABEL_STUDIO_HOST = os.getenv('LABEL_STUDIO_HOST', 'http://localhost:8080')
    LABEL_STUDIO_API_KEY = os.getenv('LABEL_STUDIO_API_KEY')
    START_TRAINING_EACH_N_UPDATES = int(os.getenv('START_TRAINING_EACH_N_UPDATES', 10))
    LEARNING_RATE = float(os.getenv('LEARNING_RATE', 1e-3))
    NUM_TRAIN_EPOCHS = int(os.getenv('NUM_TRAIN_EPOCHS', 100))
    WEIGHT_DECAY = float(os.getenv('WEIGHT_DECAY', 0.01))

    MODEL_DIR = os.getenv('MODEL_DIR', './results/entity-extraction')
    BASELINE_MODEL_NAME = os.getenv('BASELINE_MODEL_NAME', 'TinyLlama/TinyLlama-1.1B-Chat-v1.0')
    FINETUNED_MODEL_NAME = os.getenv('FINETUNED_MODEL_NAME', 'finetuned_model')
    CURRENT_MODEL_VERSION=os.getenv('CURRENT_MODEL_VERSION', '1.0.0')
    MAX_NEW_TOKEN=int(os.getenv('MAX_NEW_TOKEN', 200))
    TEMPRATURE=float(os.getenv('TEMPRATURE', 0.1))
    TOP_P=float(os.getenv('TOP_P', 0.9))
    DEVICE = torch.device( 'cuda' if torch.cuda.is_available() else 'cpu')
    MODEL_LOAD_MODE=None


    def setup(self):
        """Configure any parameters of your model here
        """
        self.set("model_version", self.CURRENT_MODEL_VERSION)

   

    def predict_external(self, texts, **kwargs) -> ModelResponse:
        """ Write your inference logic here
            :param texts: [List of text in JSON format]
            :return model_response
                ModelResponse(predictions=predictions) with
                predictions: [Predictions array in JSON format](https://labelstud.io/guide/export.html#Label-Studio-JSON-format-of-annotated-tasks)
        """
        return self.prediction(texts,None,**kwargs)
        

    def getModelPath(self,mode='Base',finetunedVersion=None):
        if mode == 'Base':
                return self.BASELINE_MODEL_NAME # str(pathlib.Path(self.MODEL_DIR)/self.BASELINE_MODEL_NAME)
        elif mode == 'Finetunned':
            # return str(pathlib.Path(self.MODEL_DIR)/self.FINETUNED_MODEL_NAME/(finetunedVersion if finetunedVersion is not None else self.CURRENT_MODEL_VERSION))
            return str(pathlib.Path(self.MODEL_DIR)/self.FINETUNED_MODEL_NAME)
        else:
            return None
    
    def loadModel(self,mode='Base'):
        chk_path = self.getModelPath(mode,self.CURRENT_MODEL_VERSION)
        logger.info(f"Loading {mode.lower()} model from {chk_path}")

        tokenizer = AutoTokenizer.from_pretrained(chk_path)
        model = AutoModelForCausalLM.from_pretrained(chk_path, torch_dtype=torch.float16, device_map="auto")
        # return pipeline("text2text-generation", model=model, tokenizer=tokenizer)
        return model,tokenizer

    def lazyInit(self):
        global model
        global tokenizer
        if model is None: 
            try:
                model,tokenizer = self.loadModel('Finetunned')
                self.MODEL_LOAD_MODE = 'Finetunned'
            except Exception as e:
                logger.error(str(e), exc_info=True)
                model,tokenizer = self.loadModel()
                self.MODEL_LOAD_MODE = 'Base'

    def getNextVersion(self, model_dir, bump='minor'):
        
        if not os.path.exists(model_dir):
            os.makedirs(model_dir)
            return '1.0.0'

        versions = [d for d in os.listdir(model_dir) if re.match(r'\d+\.\d+\.\d+', d)]
        versions.sort(key=lambda v: list(map(int, v.split('.'))))
        
        last_version = versions[-1]
        major, minor, patch = map(int, last_version.split('.'))

        if bump == 'patch':
            patch += 1
        elif bump == 'minor':
            minor += 1
            patch = 0
        elif bump == 'major':
            major += 1
            minor = patch = 0

        return f'{major}.{minor}.{patch}'

    def updateEnvFile(self, key, value ):
        # Load existing values
        env_path= dotenv.find_dotenv()
        dotenv.load_dotenv(env_path)

        dotenv.set_key(env_path,key, value)

        dotenv.load_dotenv(env_path, override=True)

        self.CURRENT_MODEL_VERSION = os.getenv("CURRENT_MODEL_VERSION", self.CURRENT_MODEL_VERSION)

    def _get_tasks(self, project_id):
        # download annotated tasks from Label Studio
        ls = label_studio_sdk.Client(self.LABEL_STUDIO_HOST, self.LABEL_STUDIO_API_KEY)
        project = ls.get_project(id=project_id)
        tasks = project.get_labeled_tasks()
        return tasks

    def tokenize_and_align_labels(self, examples, tokenizer):
        """
        From example https://huggingface.co/docs/transformers/en/tasks/token_classification#preprocess
        """
        tokenized_inputs = tokenizer(examples["tokens"], truncation=True, is_split_into_words=True)

        labels = []
        for i, label in enumerate(examples[f"ner_tags"]):
            word_ids = tokenized_inputs.word_ids(batch_index=i)  # Map tokens to their respective word.
            previous_word_idx = None
            label_ids = []
            for word_idx in word_ids:  # Set the special tokens to -100.
                if word_idx is None:
                    label_ids.append(-100)
                elif word_idx != previous_word_idx:  # Only label the first token of a given word.
                    label_ids.append(label[word_idx])
                else:
                    label_ids.append(-100)
                previous_word_idx = word_idx
            labels.append(label_ids)

        tokenized_inputs["labels"] = labels
        return tokenized_inputs


    def prediction(self, texts:str, context: Optional[Dict] = None, **kwargs) -> ModelResponse:
        """ Write your inference logic here
            :param text: text to be available for prediction
            :param context: [Label Studio context in JSON format](https://labelstud.io/guide/ml_create#Implement-prediction-logic)
            :return model_response
                ModelResponse(predictions=predictions) with
                predictions: [Predictions array in JSON format](https://labelstud.io/guide/export.html#Label-Studio-JSON-format-of-annotated-tasks)
        """
        self.lazyInit()

        if not isinstance(texts, str):
            request_id = texts[-1]["id"]
            text = texts[-1]["text"]     

        PROMPT_TEMPLATE_FILE_PATH = self.getModelRootDirectory()+"\\prompt_templates\\prompt_default.txt"

        with open(PROMPT_TEMPLATE_FILE_PATH, "r", encoding="utf-8") as file:
            prompt_template = file.read()


        # prompt_template = f"""
        #     You are an intelligent assistant. Extract the following fields from the email content below.

        #     Return ONLY a valid JSON object with extracted values:
        #     Fields to extract:
        #     - customer_name
        #     - customer_email
        #     - trading_account_number
        #     - dp_id
        #     - dp_account_number
        #     - bank_account_number

        #     Email Content:
        #     {text}

        #     """


        prompt = prompt_template.replace('{text}', text.strip())
        # run predictions
        # model_predictions = model(prompt_template,max_new_tokens=256)[0]['generated_text']

        # inputs=tokenizer(prompt,return_tensors="pt",truncation=True,max_length=1024)
        # outputs=model.generate(**inputs,max_new_tokens=300, temperature=0.0)
        # model_predictions=tokenizer.decode(outputs[0],skip_special_tokens=True)


        inputs = tokenizer(prompt, return_tensors="pt", truncation=True,max_length=1024).to(model.device)

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=self.MAX_NEW_TOKEN,
                temperature=self.TEMPRATURE,
                top_p=self.TOP_P,
                do_sample=False,
                pad_token_id=tokenizer.eos_token_id
            )

        model_predictions = tokenizer.decode(outputs[0], skip_special_tokens=True)
        model_predictions= model_predictions.split("[INST]")[-1].strip()



        logger.info(model_predictions)
        result=[]

        result.append( {
            "id":request_id,
            "from_name": "instruction",
            "to_name": "prompt",
            "type": "textarea",
            "value": {
            "text": [
                model_predictions
            ],
            "type": "json"
            # "report":analysis_result
            }
        })


        predictions = [{
            "model_version": self.get("model_version"),
            "score": 0.99,
            "result": result
        }]
        
        return ModelResponse(predictions=predictions, model_version=self.get('model_version'))

