async function process(appDriver, params, log, saveElementMap) {
    //await saveElementMap(appDriver);
    //log(JSON.stringify(params));
    let rslt = await appDriver.invoke({ selector: { automationId: 'DirectSignIn' } });
    if (rslt.rc != 0) return rslt;
    return { rc: 0 };
}

module.exports = { process };