const fs = require('fs');
require('../app/modulesLoader');
const { config, winAppDriver, util, bfs } = global.modules;

async function runProcess() {
    let rslt;
    let script_file = `${global.rootDir}/unlock/${config.rpa.unlock_script_file}`;
    rslt = await bfs.fileExists(script_file);
    if (rslt.rc != 0) return rslt;
    if (rslt.data != true) {
        script_file = `${config.folders.resources.published.scripts.rpa.win.rule}/${config.rpa.unlock_script_file}`;
    }
    rslt = await bfs.fileExists(script_file);
    if (rslt.rc != 0) return rslt;
    if (rslt.data != true) {
        return { rc: 1, msg: `${script_file} not found` };
    }

    let params = process.argv[2];

    if (params != null) {
        rslt = util.parseJson(params);
        if (rslt.rc == 0) {
            params = rslt.data;
        }
    }

    const { WinAppDriver } = winAppDriver;
    let appDriver = new WinAppDriver();

    let automationClient = appDriver.automationClient;

    rslt = automationClient.enumWindows();
    if (rslt.rc != 0) return rslt;
    let windowList = rslt.data;
    let winList = [];
    let handle;
    for (let winData of windowList) {
        rslt = automationClient.getExecutablePath(winData.handle);
        if (rslt.rc != 0) return rslt;
        let executablePath = rslt.data;
        winList.push(executablePath + ' => ' + winData.title + ' ' + winData.handle);
        if (winData.title == 'Windows sign-in') {
            handle = winData.handle;
        }
    }
    winList.sort();
    //log(winList.join('\r\n'));

    if (handle == null) {
        return { rc: 1, msg: 'Windows sign-in not found' };
    }
    appDriver.handle = handle;

    let scriptFile = require(script_file);
    rslt = await scriptFile.process(appDriver, params, log, saveElementMap);
    if (rslt.rc != 0) return rslt;

    return { rc: 0 };
}

async function start() {
    let rslt;
    try {
        rslt = await runProcess();
        if (rslt.rc == 0) {
            log('Success');
        } else {
            log('Error.\r\n' + rslt.msg);
        }
    } catch (err) {
        log(err.message + '\nAt: ' + err.stack);
    }
    process.exit();
}

function log(msg) {
    try {
        fs.appendFileSync(`${config.folders.runtime.logs.root}/ComputerUnlock.txt`, msg + '\r\n');
    } catch (err) {
        console.log(err.message);
    }
}

async function saveElementMap(appDriver) {
    let rslt = await appDriver.getElementMap(true);
    if (rslt.rc != 0) return rslt;
    let elementMap = rslt.data;
    await bfs.writeFile(`${config.folders.runtime.logs.root}/ComputerUnlock.json`, JSON.stringify(elementMap, null, '\t'));
    return { rc: 0 };
}

start();