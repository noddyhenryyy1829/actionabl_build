const fs = require('fs');
require('../app/modulesLoader');

const { winAppDriver, util, Buff } = global.modules;

log('Start ComputerUnlockListener');
//log(JSON.stringify(process.argv));

let processArgs = {};
if (process.argv.length > 2) {
    let arg = process.argv[2];
    arg = arg.replaceAll('~', ":");
    let rslt = util.parseJson(arg);
    if (rslt.rc != 0) {
        log(rslt.msg);
    } else {
        processArgs = rslt.data;
    }
}

let http_port = processArgs.http_port || 3002;

// Setup Server
const express = require('express');
const http = require('http');
const cors = require('cors');

const app = express();

async function start() {
    app.use(express.urlencoded({ extended: false }, { limit: '50mb' }));
    app.use(express.raw({ limit: '50mb' }));
    app.use(cors());
    app.use(express.json());
    app.use(function (req, res, next) {
        processRequest(req, res);
    });

    const httpServer = http.createServer(app);
    const server = httpServer.listen(http_port, 'localhost');
    server.on('listening', function () {
        const addr = server.address();
        console.debug('Computer Unlock Listening on http port ' + addr.port);
    });
}

async function processRequest(req, res) {
    let params = Buff.parseBytes(req.body);
    params = { ...processArgs, ...params };

    let rslt = { rc: 0 };

    const { WinAppDriver } = winAppDriver;
    let appDriver = new WinAppDriver();
    let automationClient = appDriver.automationClient;
    params = JSON.stringify(params);
    params = params.replaceAll('"', "'");
    rslt = await automationClient.startProcess('node ' + __dirname + '\\computerUnlock ' + JSON.stringify(params));

    let bytes = Buff.bytify(rslt);
    bytes = Buffer.from(bytes);
    res.status(200).send(bytes);
}

function log(msg) {
    try {
        fs.appendFileSync('C:/Work/ComputerUnlockListener.txt', msg + '\r\n');
    } catch (err) {
        console.log(err.message);
    }
}

start();