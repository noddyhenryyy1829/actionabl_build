const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
const { config, constants, constants_r, GenericScriptBase, bfs, cacheService, util, Buff } = global.modules;

const lookups = {
    font: ['Arial', 'Courier New', 'Georgia', 'Times New Roman', 'Trebuchet MS', 'Verdana', 'Calibri', 'Tahoma'],
    alignment: { left: 'Left', center: 'Center', right: 'Right' },
    link_type: ['Anchor', 'Button'],
    greetings: ['Hi', 'Dear', 'Hello', 'Greetings'],
};

class CustomScript extends GenericScriptBase {
    static get label() { return 'Standard'; }
    static get actions() {
        let skipWhenField = { skip_when: { label: 'Skip Section When' } };
        let skipWhenFieldTd = { typ: 'td', children: { typ: 'field', id: 'skip_when' } };
        return {
            greetings: {
                label: 'Greetings',
                fields: {
                    ...skipWhenField,
                    greetings: { label: 'Greetings', field_attrs: { lookup: lookups.greetings } },
                    recipient_name: { label: 'Recipient Name' }
                },
                layout: {
                    typ: 'table', className: 'tbl_form', children: [
                        { typ: 'tr', children: [{ ...skipWhenFieldTd, colSpan: 2 }] },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'greetings' } },
                                { typ: 'td', children: { typ: 'field', id: 'recipient_name' } },
                            ]
                        },
                    ]
                }
            },
            link: {
                label: 'Link',
                fields: {
                    ...skipWhenField,
                    link_type: { label: 'Type', field_attrs: { lookup: lookups.link_type } },
                    text: { label: 'Text' },
                    url: { label: 'URL', field_attrs: { freeSolo: true, lookup: constants_r.externalActionType } },
                    params: { label: 'Link Parameters' },
                    font: { label: 'Font', field_attrs: { lookup: lookups.font } },
                    font_size: { label: 'Font Size' },
                    color: { label: 'Color', fldTyp: constants.fieldDisplayType.Color },
                    background_color: { label: 'Background Color', fldTyp: constants.fieldDisplayType.Color },
                    alignment: { label: 'Alignment', field_attrs: { lookup: lookups.alignment } }
                },
                layout: {
                    typ: 'table', className: 'tbl_form', children: [
                        { typ: 'tr', children: [{ ...skipWhenFieldTd, colSpan: 4 }] },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'link_type' } },
                                { typ: 'td', children: { typ: 'field', id: 'text' } },
                                { typ: 'td', children: { typ: 'field', id: 'url' } },
                                { typ: 'td', children: { typ: 'field', id: 'params' } },
                            ]
                        },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'font' } },
                                { typ: 'td', children: { typ: 'field', id: 'font_size' } },
                                { typ: 'td', children: { typ: 'field', id: 'color' } },
                                { typ: 'td', children: { typ: 'field', id: 'background_color' } },
                            ]
                        },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'alignment' } },
                            ]
                        }
                    ]
                }
            },
            paragraph: {
                label: 'Paragraph',
                display_type: 'html',
                fields: {
                    ...skipWhenField,
                    text: {}
                }
            },
            plain_text: {
                label: 'Text',
                fields: {
                    ...skipWhenField,
                    font: { label: 'Font', field_attrs: { lookup: lookups.font } },
                    font_size: { label: 'Font Size' },
                    color: { label: 'Color', fldTyp: constants.fieldDisplayType.Color },
                    background_color: { label: 'Background Color', fldTyp: constants.fieldDisplayType.Color },
                    text: { label: 'Text', width: '100%', field_attrs: { multiline: true, rows: 10, } },
                    alignment: { label: 'Alignment', field_attrs: { lookup: lookups.alignment } }
                },
                layout: {
                    typ: 'table', className: 'tbl_form', children: [
                        { typ: 'tr', children: [{ ...skipWhenFieldTd, colSpan: 4 }] },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'font' } },
                                { typ: 'td', children: { typ: 'field', id: 'font_size' } },
                                { typ: 'td', children: { typ: 'field', id: 'color' } },
                                { typ: 'td', children: { typ: 'field', id: 'background_color' } },
                            ]
                        },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'alignment' } }
                            ]
                        },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', colSpan: 4, children: { typ: 'field', id: 'text' } },
                            ]
                        }
                    ]
                }
            },
            image: {
                label: 'Image',
                fields: {
                    ...skipWhenField,
                    image: { label: 'Image', fldTyp: constants.fieldDisplayType.FileSelect, field_attrs: { folderType: 'resource', folder: 'Templates/Email' } },
                    width: { label: 'Width' },
                    height: { label: 'Height' },
                    alignment: { label: 'Alignment', field_attrs: { lookup: lookups.alignment } }
                },
                layout: {
                    typ: 'table', className: 'tbl_form', children: [
                        { typ: 'tr', children: [{ ...skipWhenFieldTd, colSpan: 4 }] },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'image' } },
                                { typ: 'td', children: { typ: 'field', id: 'width' } },
                                { typ: 'td', children: { typ: 'field', id: 'height' } },
                                { typ: 'td', children: { typ: 'field', id: 'alignment' } }
                            ]
                        }
                    ]
                }
            },
            table: {
                label: 'Table',
                fields: {
                    ...skipWhenField,
                    alignment: { label: 'Data Alignment', field_attrs: { lookup: lookups.alignment } },
                    header_text: { label: 'Table Header' },
                    rows: { label: 'Table Rows (field)' },
                    col_headers: { label: 'Column Headers' },
                    col_ids: { label: 'Fields Ids' }
                },
                layout: {
                    typ: 'table', className: 'tbl_form', children: [
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'alignment' } },
                                { ...skipWhenFieldTd, colSpan: 3 }
                            ]
                        },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'header_text' } },
                                { typ: 'td', children: { typ: 'field', id: 'rows' } },
                                { typ: 'td', children: { typ: 'field', id: 'col_headers' } },
                                { typ: 'td', children: { typ: 'field', id: 'col_ids' } },
                            ]
                        },
                    ]
                }
            },
            section: {
                label: 'Section Template',
                fields: {
                    ...skipWhenField,
                    record_id: { label: 'Section Template Record', fldTyp: 'fldRecord', field_attrs: { type: constants.recordType.EmailTemplateSection } },
                },
                layout: {
                    typ: 'table', className: 'tbl_form', children: [
                        { typ: 'tr', children: [{ ...skipWhenFieldTd }] },
                        {
                            typ: 'tr', children: [
                                { typ: 'td', children: { typ: 'field', id: 'record_id' } },
                            ]
                        },
                    ]
                }
            },
            custom: {
                label: 'Custom',
                fields: {
                    script: { label: 'Script', fldTyp: constants.fieldDisplayType.JavaScript },
                },
                layout: {
                    typ: 'table', className: 'tbl_form', children: [
                        { typ: 'tr', children: [{ typ: 'td', children: { typ: 'field', id: 'script' } }] },
                    ]
                }
            },
        };
    }

    constructor() {
        super();
        let self = this;
        self.isMJML = config.email.use_mjml;
    }

    async greetings($) {
        let self = this;
        let { isMJML } = self;
        let { greetings = 'Hi', recipient_name } = $;

        let text = recipient_name ? `${greetings} ${recipient_name},` : `${greetings},`;

        let ele;
        if (isMJML) {
            ele = { typ: 'mj-text', children: text };
        } else {
            ele = { typ: 'div', className: 'email-block greetings', children: text };
        }

        return { rc: 0, data: ele };
    }

    async paragraph($) {
        let self = this;
        let { isMJML } = self;
        let { text } = $;
        if (text == null) return { rc: 0 };

        text = text.replaceAll('<br></p>', '</p>');
        let ele = { html: text };

        if (isMJML == true) {
            ele = { typ: 'mj-text', skipReplaceNextLine: true, children: ele };
        } else {
            ele = { typ: 'div', className: 'email-block paragraph', children: ele };
        }

        return { rc: 0, data: ele };
    }

    async link($) {
        let self = this;
        let { isMJML } = self;
        let { btn_bg, btn_text } = config.email.colors;
        let { link_type, text, url, params, alignment = 'center' } = $;
        let { font, font_size, color = btn_text, background_color = btn_bg } = $;

        if (params != null) {
            params = params.trim();
            if (params === '') params = null;
        }

        if (params != null) {
            let rslt = util.parseJson(params);
            if (rslt.rc != 0) return { rc: 1, msg: `Invalid parameters ${params}` };
            params = Buff.toBase64(rslt.data);
            const sep = url.includes('?') ? '&' : '?';
            url = `${url}${sep}params=${params}`;
        }

        let aStyles = [`display: inline-block;text-decoration: none !important; color: ${color} !important; background-color: ${background_color} !important;`];
        if (font) aStyles.push(`font-family: ${font} !important;`);
        if (font_size) aStyles.push(`font-size: ${font_size}px !important;`);

        let ele;
        if (link_type === 'Button') {
            if (isMJML) {
                let attrs = { href: url, align: alignment, style: aStyles.join(' ') };
                ele = { typ: 'mj-button', attrs, text };
            } else {
                aStyles.push('padding: 8px 24px; border-radius: 8px;');
                let centerStyle = [`color:${color}; line-height:24px;`];
                if (font) centerStyle.push(`font-family:${font};`);
                if (font_size) centerStyle.push(`font-size:${font_size}px;`);
                let width = Math.max(text.length * 8 + 32, 100);

                let buttonTable = {
                    typ: 'table', attrs: { cellpadding: '0', cellspacing: '0', border: '0', role: 'presentation', align: alignment },
                    children: {
                        typ: 'tr',
                        children: {
                            typ: 'td',
                            children: {
                                typ: 'raw', text: `<!--[if mso]>
<v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" href="${url}" style="height:32px; width:${width}px" arcsize="8%" strokecolor="${background_color}" fillcolor="${background_color}">
  <w:anchorlock/>
  <v:textbox inset="0,0,0,0">
  <center style="${centerStyle.join(' ')}">
    ${text}
  </center>
  </v:textbox>
</v:roundrect>
<![endif]-->
<!--[if !mso]><!-- -->
<a href="${url}" target="_blank" style="${aStyles.join(' ')}">${text}</a>
<!--<![endif]-->
`.trim()
                            }
                        }
                    }
                };
                ele = {
                    typ: 'div', className: 'email-block link', children: buttonTable
                };
            }
        } else {
            if (isMJML) {
                let attrs = { align: alignment, style: aStyles.join(' ') };
                ele = { typ: 'mj-text', attrs, children: { typ: 'a', text, attrs: { href: url } } };
            } else {
                let anchor = { typ: 'a', children: text, attrs: { href: url, target: '_blank' }, style: aStyles.join(' ') };
                ele = { typ: 'div', className: 'email-block link', style: `text-align: ${alignment};`, children: anchor };
            }
        }

        return { rc: 0, data: ele };
    }

    async plain_text($) {
        let self = this;
        let { isMJML } = self;
        let { font, font_size, text, color, background_color, alignment } = $;
        if (text == null) return { rc: 0 };

        let styleParts = [];
        if (font) styleParts.push(`font-family: ${font};`);
        if (font_size) styleParts.push(`font-size: ${font_size}px;`);
        if (color) styleParts.push(`color: ${color};`);
        if (background_color) styleParts.push(`background-color: ${background_color};`);
        if (alignment) styleParts.push(`text-align: ${alignment};`);

        let ele;
        if (isMJML) {
            ele = { typ: 'mj-text', children: { html: text } };
            if (styleParts.length > 0) ele.attrs = { style: styleParts.join(' ') };
        } else {
            text = text.replaceAll('\r\n', '<br>').replaceAll('\n', '<br>');
            ele = { typ: 'div', className: 'email-block text', children: text };
            if (styleParts.length > 0) ele.style = styleParts.join(' ');
        }

        return { rc: 0, data: ele };
    }

    async image($) {
        let { image, width, height, alignment, folder } = $;
        let folderPath = config.folders.resources.published.templates.email.root;
        if (folder != null) folderPath = config.folders.resources.published.files.root + '/' + folder;

        let filePath = `${folderPath}/${image}`;
        let rslt = await bfs.readFileRaw(filePath);
        if (rslt.rc != 0) return rslt;

        let fileBytes = rslt.data;
        let base64 = Buffer.from(fileBytes).toString('base64');
        let extension = bfs.getExtension(filePath);
        let src = `data:image/${extension};base64,${base64}`;

        let styleParts = ['max-width: 100%;', 'height: auto;'];
        if (width) styleParts.push(`width: ${width}px;`);
        if (height) styleParts.push(`height: ${height}px;`);

        let ele = {
            typ: 'div', className: 'email-block image', children: { typ: 'img', attrs: { src }, style: styleParts.join(' ') }
        };

        if (alignment) ele.style = `text-align: ${alignment};`;

        return { rc: 0, data: ele };
    }

    async table($, emailData) {
        let self = this;
        let { isMJML } = self;
        let { header_text, col_headers, col_ids, rows, alignment } = $;

        rows = emailData[rows];
        if (rows == null) return { rc: 0 };

        col_headers = col_headers.split(',');
        col_ids = col_ids.split(',');

        let { header_bg, border } = config.email.table;
        let titleStyle = `background-color:${header_bg}; font-weight: bold; padding: 8px;`;
        let headerStyle = `font-weight: 500; padding: 8px; border: ${border};`;
        let dataStyle = `padding: 8px; border: ${border};`;
        if (alignment) {
            headerStyle += ` text-align: ${alignment};`;
            dataStyle += ` text-align: ${alignment};`;
        }

        let trs = [];

        // Optional title row
        if (header_text != null) {
            let td = {
                typ: 'td', text: header_text, style: titleStyle,
                attrs: { colSpan: col_headers.length, align: 'center' },
            };
            trs.push({ typ: 'tr', children: [td] });
        }

        // Table column headers
        let tds = [];
        for (let col_header of col_headers) {
            tds.push({ typ: 'th', text: col_header.trim(), attrs: { scope: 'col' }, style: headerStyle });
        }
        trs.push({ typ: 'tr', className: 'header-row', children: tds });

        // Table data rows
        for (let row of rows) {
            tds = [];
            for (let col_id of col_ids) {
                tds.push({ typ: 'td', text: row[col_id.trim()], style: dataStyle });
            }
            trs.push({ typ: 'tr', children: tds });
        }

        let ele;
        if (isMJML) {
            ele = { typ: 'mj-table', children: trs };
        } else {
            ele = {
                typ: 'div', className: 'email-block table',
                children: {
                    typ: 'table', className: 'email-table', children: trs,
                    attrs: { cellpadding: '0', cellspacing: '0', border: '0' },
                    style: 'border-collapse: collapse; width: 100%;'
                }
            };
        }

        return { rc: 0, data: ele };
    }

    async section($) {
        let { record_id } = $;
        let rslt = await cacheService.getRecord(record_id);
        if (rslt.rc != 0) return rslt;
        if (rslt.data == null) return { rc: 1, msg: 'Missing record ' + record_id };
        let sections = rslt.data.config_dat.body;
        return { rc: 0, data: sections };
    }

    async custom($, emailData) {
        let self = this;
        let fnScript = `
        let self = this;
        ${$.script};
        `;
        let fn = new AsyncFunction('$', 'emailData', fnScript);
        fn = fn.bind(self);
        let rslt = await fn($, emailData);
        return rslt;
    }
}

module.exports = CustomScript;