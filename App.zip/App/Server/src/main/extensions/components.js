const { constants, constants_r } = global.modules;
const data = {
    rp_automation_connector: {
        dmn: {
            category: 2,
            type: 'dmn',
            name: 'DMN',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        rule: {
            category: 3,
            type: 'rule',
            name: 'Rule',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        qc: {
            category: 9,
            type: 'qc',
            name: 'QC',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        cron: {
            category: 0,
            type: 'cron',
            name: 'Cron',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        http: {
            category: 0,
            type: 'http',
            name: 'Http',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        report_scheduler_job: {
            category: 8,
            type: 'report_scheduler_job',
            name: 'Report Scheduler',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        data_archive_scheduler_job: {
            category: 8,
            type: 'data_archive_scheduler_job',
            name: 'Data Archive Scheduler',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_monitor_scheduler_job: {
            category: 8,
            type: 'task_monitor_scheduler_job',
            name: 'Task Monitor Scheduler',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        folder_archive_scheduler_job: {
            category: 8,
            type: 'folder_archive_scheduler_job',
            name: 'Folder Archive Scheduler',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        license_verifier_job: {
            category: 8,
            type: 'license_verifier_job',
            name: 'License Verifier',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        batch_job_scheduler_job: {
            category: 8,
            type: 'batch_job_scheduler_job',
            name: 'Batch Job Scheduler',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_event_processor_job: {
            category: 8,
            type: 'task_event_processor_job',
            name: 'Task Event Processor',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        jh_operations_job: {
            category: 8,
            type: 'jh_operations_job',
            name: 'Jack Henry Operations',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_metrics_scheduler_job: {
            category: 8,
            type: 'task_metrics_scheduler_job',
            name: 'Task metrics Scheduler',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        support_mail_reader_job: {
            category: 0,
            type: 'read_email',
            name: 'Read Support Emails',
            active: true,
            config_dat: {
                email_account: 'support_email_account',
                email_fields: ['received_date', 'sender', 'message_uid', 'subject', 'email_message'],
                save_attachments: true,
                attachment_category: 1,
                attachment_access_level: 2,
                save_email: true,
                fetch_count: 10
            },
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        rpa: {
            category: 5,
            type: 'actionabl_rpa',
            name: 'Actionabl RPA',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        uipath: {
            category: 5,
            type: 'uipath',
            name: 'UiPath',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        automation_anywhere: {
            category: 5,
            type: 'automation_anywhere',
            name: 'Automation Anywhere',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        blue_prism: {
            category: 5,
            type: 'blue_prism',
            name: 'BluePrism',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        ocr: {
            category: 4,
            type: 'actionabl_ocr',
            name: 'Actionabl OCR',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        hyper_science: {
            category: 4,
            type: 'hyper_science',
            name: 'HyperScience',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        vidado: {
            category: 4,
            type: 'vidado',
            name: 'Vidado',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        abbyy: {
            category: 4,
            type: 'abbyy',
            name: 'ABBYY',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        ai_space: {
            category: 6,
            type: 'ai_space',
            name: 'AI Space',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        notification_email: {
            category: 7,
            type: 'send_email',
            name: 'Notification Email',
            active: true,
            config_dat: {
                email_template: 'task_notification_email_template',
                email_type: 2
            },
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
        notification_message: {
            category: 7,
            type: 'send_message',
            name: 'Notification Message',
            active: true,
            config_dat: {
                message_template: 'task_notification_message_template'
            },
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
        push_notification: {
            category: 7,
            type: 'push_notification',
            name: 'Push Notification',
            active: true,
            config_dat: {
                message_template: 'task_notification_message_template'
            },
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
        ai_agent_heal_data_error: {
            category: 6,
            type: 'ai_agent_heal_data_error',
            name: 'AI Agent - Heal Data Error',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        ai_agent_heal_extraction_error: {
            category: 6,
            type: 'ai_agent_heal_extraction_error',
            name: 'AI Agent - Heal Extraction Error',
            config_dat: {
                confidence_threshold: 0.8
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
    },

    /*********************************/

    rp_automation_manager: {
        report_scheduler_job: {
            schedule_type: 'standalone',
            automation_id: 'report_scheduler_job',
            execution_mode: 2,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        data_archive_scheduler_job: {
            schedule_type: 'standalone',
            automation_id: 'data_archive_scheduler_job',
            execution_mode: 2,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_monitor_scheduler_job: {
            schedule_type: 'standalone',
            automation_id: 'task_monitor_scheduler_job',
            execution_mode: 2,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        folder_archive_scheduler_job: {
            schedule_type: 'standalone',
            automation_id: 'folder_archive_scheduler_job',
            execution_mode: 2,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        license_verifier_job: {
            schedule_type: 'standalone',
            automation_id: 'license_verifier_job',
            execution_mode: 2,
            disabled: false,
            system_job: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        batch_job_scheduler_job: {
            schedule_type: 'standalone',
            automation_id: 'batch_job_scheduler_job',
            execution_mode: 2,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_event_processor_job: {
            schedule_type: 'standalone',
            automation_id: 'task_event_processor_job',
            execution_mode: 2,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        jh_operations_job: {
            schedule_type: 'standalone',
            automation_id: 'jh_operations_job',
            execution_mode: 3,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_metrics_scheduler_job: {
            schedule_type: 'standalone',
            automation_id: 'task_metrics_scheduler_job',
            execution_mode: 2,
            cron_schedule: 'everyday_1am',
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        support_mail_reader_job: {
            schedule_type: 'standalone',
            automation_id: 'support_mail_reader_job',
            execution_mode: 2,
            run_interval: 'sec',
            interval_period: 5,
            disabled: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        'send_notification-send_email': {
            schedule_type: 'process',
            automation_id: 'notification_email',
            proc_def_key: 'send_notification',
            task_key: 'send_email',
            execution_mode: 1,
            active: true,
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
        'send_notification-send_message': {
            schedule_type: 'process',
            automation_id: 'notification_message',
            proc_def_key: 'send_notification',
            task_key: 'send_message',
            execution_mode: 1,
            active: true,
            updated_at: 978325200000,
            updated_by: 'actionabl'
        }
    },

    /*********************************/

    rp_data_source_def: {
        generic: {
            name: 'Generic (Key, Value)',
            category: 1,
            config_dat: [
                {
                    field_name: 'key',
                    field_title: 'Key',
                    input: true
                },
                {
                    field_name: 'value',
                    field_title: 'Value'
                }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        dmn_generic: {
            name: 'Generic (Key, Value)',
            category: 2,
            config_dat: [
                {
                    field_name: 'key',
                    field_title: 'Key',
                    input: true
                },
                {
                    field_name: 'value',
                    field_title: 'Value'
                }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        pa_rpa: {
            name: 'RPA Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'application_type', field_title: 'Application Type', input: true, lookup: constants_r.applicationType },
                { field_name: 'num_screens', field_title: 'Number of Screens', input: true },
                { field_name: 'num_rpa_fields', field_title: 'Number of Fields', input: true },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
                { field_name: 'internal_capability', field_title: 'Internal Capability?', type: constants.fieldType.Boolean }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_ocr: {
            name: 'OCR Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'file_type', field_title: 'File Type', input: true, lookup: constants_r.ocrFileType },
                { field_name: 'data_structure', field_title: 'Data Structure', input: true, lookup: constants_r.ocrDataStructure },
                { field_name: 'text_type', field_title: 'Text Type', input: true, lookup: constants_r.ocrTextType },
                { field_name: 'num_pages', field_title: 'Number of Pages', input: true },
                { field_name: 'num_ocr_fields', field_title: 'Number of Fields', input: true },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
                { field_name: 'internal_capability', field_title: 'Internal Capability?', type: constants.fieldType.Boolean }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_user: {
            name: 'User/QC Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'custom_layout', field_title: 'Custom Layout?', type: constants.fieldType.Boolean, input: true },
                { field_name: 'num_user_fields', field_title: 'Number of Fields', input: true },
                { field_name: 'num_validations', field_title: 'Number of Validations', input: true },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_rule: {
            name: 'Rule Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'rule_type', field_title: 'Rule Type', input: true, lookup: constants_r.ruleType },
                { field_name: 'num_rules', field_title: 'Number of Rules', input: true },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_decision: {
            name: 'Decision Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'num_conditions', field_title: 'Number of Conditions', input: true },
                { field_name: 'num_rules', field_title: 'Number of Rules', input: true },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_ml: {
            name: 'ML Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'algo_type', field_title: 'Algorithm Type', input: true, lookup: constants_r.algorithmType },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
                { field_name: 'internal_capability', field_title: 'Internal Capability?', type: constants.fieldType.Boolean }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_service: {
            name: 'Service Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'service_type', field_title: 'Service Type', input: true, lookup: constants_r.serviceType },
                { field_name: 'service_provider', field_title: 'Service Provider' },
                { field_name: 'num_inputs', field_title: 'Number of Input Fields', input: true },
                { field_name: 'num_outputs', field_title: 'Number of Output Fields', input: true },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_bot: {
            name: 'Bot Task',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'bot_type', field_title: 'Bot Type', input: true, lookup: constants_r.botType },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_start_event: {
            name: 'Start Event',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'start_event_type', field_title: 'Start Event Type', input: true, lookup: constants_r.startEventType },
                { field_name: 'points', field_title: 'Points', lookup: constants_r.processAssessmentPoints },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_process: {
            name: 'Process Assessment',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'points', field_title: 'Total Points', input: true },
                { field_name: 'complexity', field_title: 'Complexity', lookup: constants_r.complexity },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_business_priority: {
            name: 'Business Priority',
            category: constants.dataSourceCategory.ProcessAssessment,
            config_dat: [
                { field_name: 'business_impact', field_title: 'Business Impact', input: true, lookup: constants_r.priority },
                { field_name: 'business_urgency', field_title: 'Business Urgency', input: true, lookup: constants_r.priority },
                { field_name: 'business_priority', field_title: 'Business Priority', lookup: constants_r.priority },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        }
    },

    /*********************************/

    rp_data_source: {
        pa_rpa: {
            type: constants.dataSourceDef.pa_rpa,
            name: 'RPA Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { application_type: 1, num_screens: '<= 1', num_rpa_fields: '<= 10', points: 1, internal_capability: true },
                { application_type: 1, num_screens: '<= 2', num_rpa_fields: '<= 20', points: 2, internal_capability: true },
                { application_type: 1, num_screens: '<= 3', num_rpa_fields: '<= 30', points: 3, internal_capability: true },
                { application_type: 1, num_screens: '<= 4', num_rpa_fields: '<= 40', points: 4, internal_capability: true },
                { application_type: 1, num_screens: '<= 5', num_rpa_fields: '<= 50', points: 5, internal_capability: true },
                { application_type: 1, num_screens: '<= 3', num_rpa_fields: '> 50', points: 6, internal_capability: true },
                { application_type: 1, points: 7, internal_capability: true },

                { application_type: 2, num_screens: '<= 1', num_rpa_fields: '<= 10', points: 1, internal_capability: false },
                { application_type: 2, num_screens: '<= 2', num_rpa_fields: '<= 20', points: 2, internal_capability: false },
                { application_type: 2, num_screens: '<= 3', num_rpa_fields: '<= 30', points: 3, internal_capability: false },
                { application_type: 2, num_screens: '<= 4', num_rpa_fields: '<= 40', points: 4, internal_capability: false },
                { application_type: 2, num_screens: '<= 5', num_rpa_fields: '<= 50', points: 5, internal_capability: false },
                { application_type: 2, num_screens: '<= 3', num_rpa_fields: '> 50', points: 6, internal_capability: false },
                { application_type: 2, points: 7, internal_capability: false },

                { application_type: 3, num_screens: '<= 1', num_rpa_fields: '<= 10', points: 1, internal_capability: false },
                { application_type: 3, num_screens: '<= 2', num_rpa_fields: '<= 20', points: 2, internal_capability: false },
                { application_type: 3, num_screens: '<= 3', num_rpa_fields: '<= 30', points: 3, internal_capability: false },
                { application_type: 3, num_screens: '<= 4', num_rpa_fields: '<= 40', points: 4, internal_capability: false },
                { application_type: 3, num_screens: '<= 5', num_rpa_fields: '<= 50', points: 5, internal_capability: false },
                { application_type: 3, num_screens: '<= 3', num_rpa_fields: '> 50', points: 6, internal_capability: false },
                { application_type: 3, points: 7, internal_capability: false },

                { application_type: 4, num_screens: '<= 1', num_rpa_fields: '<= 10', points: 2, internal_capability: false },
                { application_type: 4, num_screens: '<= 2', num_rpa_fields: '<= 20', points: 3, internal_capability: false },
                { application_type: 4, num_screens: '<= 3', num_rpa_fields: '<= 30', points: 4, internal_capability: false },
                { application_type: 4, num_screens: '<= 4', num_rpa_fields: '<= 40', points: 5, internal_capability: false },
                { application_type: 4, num_screens: '<= 5', num_rpa_fields: '<= 50', points: 6, internal_capability: false },
                { application_type: 4, num_screens: '<= 3', num_rpa_fields: '> 50', points: 7, internal_capability: false },
                { application_type: 4, points: 8, internal_capability: false },

                { application_type: 5, num_screens: '<= 1', num_rpa_fields: '<= 10', points: 2, internal_capability: false },
                { application_type: 5, num_screens: '<= 2', num_rpa_fields: '<= 20', points: 3, internal_capability: false },
                { application_type: 5, num_screens: '<= 3', num_rpa_fields: '<= 30', points: 4, internal_capability: false },
                { application_type: 5, num_screens: '<= 4', num_rpa_fields: '<= 40', points: 5, internal_capability: false },
                { application_type: 5, num_screens: '<= 5', num_rpa_fields: '<= 50', points: 6, internal_capability: false },
                { application_type: 5, num_screens: '<= 3', num_rpa_fields: '> 50', points: 7, internal_capability: false },
                { application_type: 5, points: 8, internal_capability: false }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_ocr: {
            type: constants.dataSourceDef.pa_ocr,
            name: 'OCR Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { file_type: 1, data_structure: 1, text_type: 1, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: true },
                { file_type: 1, data_structure: 1, text_type: 1, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: true },
                { file_type: 1, data_structure: 1, text_type: 1, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: true },
                { file_type: 1, data_structure: 1, text_type: 1, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: true },
                { file_type: 1, data_structure: 1, text_type: 1, points: 6, internal_capability: true },

                { file_type: 1, data_structure: 2, text_type: 1, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: true },
                { file_type: 1, data_structure: 2, text_type: 1, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: true },
                { file_type: 1, data_structure: 2, text_type: 1, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: true },
                { file_type: 1, data_structure: 2, text_type: 1, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: true },
                { file_type: 1, data_structure: 2, text_type: 1, points: 5, internal_capability: true },

                { file_type: 1, data_structure: 3, text_type: 1, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: false },
                { file_type: 1, data_structure: 3, text_type: 1, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: false },
                { file_type: 1, data_structure: 3, text_type: 1, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: false },
                { file_type: 1, data_structure: 3, text_type: 1, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: false },
                { file_type: 1, data_structure: 3, text_type: 1, points: 5, internal_capability: false },

                { file_type: 2, data_structure: 1, text_type: 1, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 1, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 1, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 1, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 1, points: 6, internal_capability: false },

                { file_type: 2, data_structure: 2, text_type: 1, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 1, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 1, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 1, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 1, points: 6, internal_capability: false },

                { file_type: 2, data_structure: 3, text_type: 1, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 1, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 1, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 1, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 1, points: 6, internal_capability: false },

                { file_type: 2, data_structure: 1, text_type: 2, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 2, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 2, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 2, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: false },
                { file_type: 2, data_structure: 1, text_type: 2, points: 6, internal_capability: false },

                { file_type: 2, data_structure: 2, text_type: 2, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 2, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 2, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 2, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: false },
                { file_type: 2, data_structure: 2, text_type: 2, points: 6, internal_capability: false },

                { file_type: 2, data_structure: 3, text_type: 2, num_pages: '<= 1', num_ocr_fields: '<= 10', points: 2, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 2, num_pages: '<= 2', num_ocr_fields: '<= 20', points: 3, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 2, num_pages: '<= 3', num_ocr_fields: '<= 30', points: 4, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 2, num_pages: '<= 2', num_ocr_fields: '> 30', points: 5, internal_capability: false },
                { file_type: 2, data_structure: 3, text_type: 2, points: 6, internal_capability: false }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_user: {
            type: constants.dataSourceDef.pa_user,
            name: 'User/QC Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { custom_layout: true, num_user_fields: '<= 20', num_validations: '<= 10', points: 2 },
                { custom_layout: true, num_user_fields: '<= 50', num_validations: '<= 15', points: 3 },
                { custom_layout: true, points: 4 },

                { custom_layout: false, num_user_fields: '<= 20', num_validations: '<= 10', points: 1 },
                { custom_layout: false, num_user_fields: '<= 50', num_validations: '<= 15', points: 1 },
                { custom_layout: false, points: 3 }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_rule: {
            type: constants.dataSourceDef.pa_rule,
            name: 'Rule Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { rule_type: 3, num_rules: '<= 5', points: 1 },
                { rule_type: 3, num_rules: '<= 10', points: 2 },
                { rule_type: 3, num_rules: '<= 20', points: 3 },
                { rule_type: 3, num_rules: '> 20', points: 4 },

                { rule_type: 4, num_rules: '<= 5', points: 1 },
                { rule_type: 4, num_rules: '<= 10', points: 2 },
                { rule_type: 4, num_rules: '<= 20', points: 3 },
                { rule_type: 4, num_rules: '> 20', points: 4 },

                { rule_type: 5, num_rules: '<= 5', points: 2 },
                { rule_type: 5, num_rules: '<= 10', points: 3 },
                { rule_type: 5, num_rules: '<= 20', points: 4 },
                { rule_type: 5, num_rules: '> 20', points: 5 },

                { rule_type: 6, num_rules: '<= 5', points: 2 },
                { rule_type: 6, num_rules: '<= 10', points: 3 },
                { rule_type: 6, num_rules: '<= 20', points: 4 },
                { rule_type: 6, num_rules: '> 20', points: 5 },

                { rule_type: 7, num_rules: '<= 5', points: 2 },
                { rule_type: 7, num_rules: '<= 10', points: 3 },
                { rule_type: 7, num_rules: '<= 20', points: 4 },
                { rule_type: 7, num_rules: '> 20', points: 5 }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_decision: {
            type: constants.dataSourceDef.pa_decision,
            name: 'Decision Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { num_conditions: '<= 2', num_rules: '<= 10', points: 1 },
                { num_conditions: '<= 3', num_rules: '<= 30', points: 2 },
                { num_conditions: '<= 5', num_rules: '<= 50', points: 3 },
                { points: 4 },
            ]
        },
        pa_ml: {
            type: constants.dataSourceDef.pa_ml,
            name: 'ML Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { algo_type: 1, points: 5, internal_capability: false },
                { algo_type: 2, points: 6, internal_capability: false },
                { algo_type: 3, points: 7, internal_capability: false },
                { algo_type: 4, points: 8, internal_capability: false }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_service: {
            type: constants.dataSourceDef.pa_service,
            name: 'Service Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { service_type: 1, num_inputs: '<= 10', num_outputs: '<= 10', points: 2 },
                { service_type: 1, num_inputs: '<= 20', num_outputs: '<= 20', points: 3 },
                { service_type: 1, num_inputs: '<= 30', num_outputs: '<= 30', points: 4 },
                { service_type: 1, points: 5 },

                { service_type: 2, num_inputs: '<= 10', num_outputs: '<= 10', points: 2 },
                { service_type: 2, num_inputs: '<= 20', num_outputs: '<= 20', points: 3 },
                { service_type: 2, num_inputs: '<= 30', num_outputs: '<= 30', points: 4 },
                { service_type: 2, points: 5 },

                { service_type: 3, num_inputs: '<= 10', num_outputs: '<= 10', points: 2 },
                { service_type: 3, num_inputs: '<= 20', num_outputs: '<= 20', points: 3 },
                { service_type: 3, num_inputs: '<= 30', num_outputs: '<= 30', points: 4 },
                { service_type: 3, points: 5 },

                { service_type: 4, num_inputs: '<= 10', num_outputs: '<= 10', points: 2 },
                { service_type: 4, num_inputs: '<= 20', num_outputs: '<= 20', points: 3 },
                { service_type: 4, num_inputs: '<= 30', num_outputs: '<= 30', points: 4 },
                { service_type: 4, points: 5 }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_bot: {
            type: constants.dataSourceDef.pa_bot,
            name: 'Bot Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { bot_type: 1, points: 2 },
                { bot_type: 2, points: 2 },
                { bot_type: 3, points: 4 },
                { points: 5 }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_start_event: {
            type: constants.dataSourceDef.pa_start_event,
            name: 'Start Event Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { start_event_type: 1, points: 2 },
                { start_event_type: 2, points: 3 },
                { start_event_type: 3, points: 2 },
                { start_event_type: 4, points: 4 },
                { start_event_type: 5, points: 3 }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_process: {
            type: constants.dataSourceDef.pa_process,
            name: 'Process Assessment',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { points: '<= 15', complexity: 1 },
                { points: '<= 30', complexity: 2 },
                { points: '<= 45', complexity: 3 },
                { points: '> 45', complexity: 4 },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        pa_business_priority: {
            type: constants.dataSourceDef.pa_business_priority,
            name: 'Business Priority',
            source: constants.dataSourceType.Entry,
            config_dat: [
                { business_impact: 1, business_urgency: 1, business_priority: 1 },
                { business_impact: 1, business_urgency: 2, business_priority: 1 },
                { business_impact: 1, business_urgency: 3, business_priority: 2 },
                { business_impact: 2, business_urgency: 1, business_priority: 1 },
                { business_impact: 2, business_urgency: 2, business_priority: 2 },
                { business_impact: 2, business_urgency: 3, business_priority: 3 },
                { business_impact: 3, business_urgency: 1, business_priority: 2 },
                { business_impact: 3, business_urgency: 2, business_priority: 3 },
                { business_impact: 3, business_urgency: 3, business_priority: 3 },
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        }
    },

    /*********************************/

    rp_field: {
        buss_id: {
            type: 1,
            name: 'Business Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        orig_buss_id: {
            type: 1,
            name: 'Origin Business Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        orig_task_id: {
            type: 1,
            name: 'Origin Task Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        process_key: {
            type: 1,
            name: 'Process Key',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_key: {
            type: 1,
            name: 'Task Key',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        proc_id: {
            type: 1,
            name: 'Process Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        task_id: {
            type: 1,
            name: 'Task Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        connector_id: {
            type: 1,
            name: 'Connector Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        stage: {
            type: 1,
            name: 'Stage',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        title: {
            type: 1,
            name: 'Title',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        errors: {
            type: 1,
            name: 'Errors',
            control_type: constants.fieldControlType.Multiline,
            config_dat: {
                size: 3
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        message: {
            type: 1,
            name: 'Message',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        error_message: {
            type: 1,
            name: 'Error Message',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        short_text: {
            type: 1,
            name: 'Short Text',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        long_text: {
            type: 1,
            name: 'Long Text',
            control_type: constants.fieldControlType.Multiline,
            config_dat: {
                size: 10
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        approved: {
            type: 4,
            name: 'Approved',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        need_review: {
            type: 4,
            name: 'Need Review',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        name: {
            type: 1,
            name: 'Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        first_name: {
            type: 1,
            name: 'First Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        last_name: {
            type: 1,
            name: 'Last Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        address: {
            type: 1,
            name: 'Address',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        email: {
            type: 1,
            name: 'Email',
            val_type: 'email',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        phone: {
            type: 1,
            name: 'Phone',
            val_type: 'phoneNumber',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        attachment: {
            type: 10,
            name: 'Attachment',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        attachment_list: {
            type: 10,
            name: 'Attachments',
            is_list: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        email_notification: {
            type: 4,
            name: 'Email Notification',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        sms_notification: {
            type: 4,
            name: 'SMS Notification',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        whatsapp_notification: {
            type: 4,
            name: 'Whatsapp Notification',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        push_notification: {
            type: 4,
            name: 'Push Notification',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        notification_fields: {
            type: 9,
            name: 'Notification Fields',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        email_account_id: {
            type: 1,
            name: 'Email Account',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        email_template_id: {
            type: 1,
            name: 'Email Template',
            control_type: constants.fieldControlType.RecordLookup,
            config_dat: {
                record_type: constants.recordType.EmailTemplate
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        message_template_id: {
            type: 1,
            name: 'Message Template',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        comm_mode: {
            type: 1,
            name: 'Communication Mode',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        save_email: {
            type: 4,
            name: 'Save Email to History',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        content_name: {
            type: 1,
            name: 'Content Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        message_uid: {
            type: 1,
            name: 'Message Uid',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        email_message_id: {
            type: 1,
            name: 'Email Message Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        email_thread_id: {
            type: 1,
            name: 'Email Thread Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        sender: {
            type: 1,
            name: 'Sender',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        cc_email: {
            type: 1,
            name: 'CC Email Id',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        subject: {
            type: 1,
            name: 'Subject',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        email_message: {
            type: 1,
            name: 'Email Message',
            control_type: constants.fieldControlType.Multiline,
            config_dat: {
                size: 20
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        recipient_email: {
            type: 1,
            name: 'Recipient Email',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        received_date: {
            type: 6,
            name: 'Received Date',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        attachment_name: {
            type: 1,
            name: 'Attachment Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        attachment_path: {
            type: 1,
            name: 'Attachment Path',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        rejection_reason: {
            type: 1,
            name: 'Rejection Reason',
            control_type: constants.fieldControlType.TextEditor,
            config_dat: {
                size: 5
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        manual_response: {
            type: 1,
            name: 'Manual Email Response',
            control_type: constants.fieldControlType.Multiline,
            config_dat: {
                size: 10
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        qc_review: {
            type: 4,
            name: 'QC Review',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        qc_reviewed: {
            type: 4,
            name: 'QC Reviewed',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        manually_completed: {
            type: 4,
            name: 'Manually Completed',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        auto_completed: {
            type: 4,
            name: 'Auto Completed',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        template_name: {
            type: 1,
            name: 'Template Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        file_name: {
            type: 1,
            name: 'File Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        file_status: {
            type: 1,
            name: 'File Status',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        file_path: {
            type: 1,
            name: 'File Path',
            control_type: constants.fieldControlType.FileSelect,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        ocr_file_path: {
            type: 1,
            name: 'OCR File Path',
            control_type: constants.fieldControlType.FileSelect,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        run_date: {
            type: 5,
            name: 'Run Date',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        company_name: {
            type: 1,
            name: 'Company Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        client_name: {
            type: 1,
            name: 'Client Name',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        has_error: {
            type: 4,
            name: 'Has Error',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        discard: {
            type: 4,
            name: 'Discard',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        status: {
            type: 1,
            name: 'Status',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        retry: {
            type: 4,
            name: 'Retry',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        ocr_field_conf_thresh: {
            type: 2,
            name: 'OCR Field Acceptance Confidence Threshold',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        }
    },

    /*********************************/

    rp_form: {
        inbound_email: {
            name: 'Inbound Email',
            type: 4,
            config_dat: {
                file: 'inbound_email.json'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        default_input_section: {
            name: 'Default Input Section',
            type: 2,
            config_dat: {
                columns: 2,
                columns_mobile: 1
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        default_output_section: {
            name: 'Default Output Section',
            type: 2,
            config_dat: {
                columns: 2,
                columns_mobile: 1
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        default_general_section: {
            name: 'Default General Section',
            type: 2,
            config_dat: {
                columns: 3,
                columns_mobile: 1
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        }
    },

    /*********************************/

    rp_rule: {
        error_check: {
            category: 1,
            type: 3,
            name: 'Check for Errors',
            config_dat: [
                {
                    condition: '$.messages && $.messages.length > 0',
                    action: 'throw $.messages'
                },
                {
                    condition: '$.errors && $.errors.length > 0',
                    action: 'throw $.errors'
                }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        datatype_validation: {
            category: 1,
            type: 2,
            name: 'Datatype Validation',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        rejection_reason: {
            category: 1,
            type: 3,
            name: 'Rejection Reason',
            config_dat: [
                {
                    condition: '$.approved !== true && $.rejection_reason == null',
                    action: 'throw "Rejection reason is missing"'
                }
            ],
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        ocr_conf_check: {
            category: 1,
            type: 2,
            name: 'OCR Confidence Check',
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        dtt_parse_date: {
            category: 3,
            type: 4,
            name: 'Parse Date - dmy',
            config_dat: {
                script: 'const { dataParser } = modules; dataParser.parseDate($, "dmy");'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        dtt_keep_after: {
            category: 3,
            type: 4,
            name: 'Keep After',
            config_dat: {
                script: 'const { dataParser } = modules; dataParser.keepAfter($);'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        dtt_keep_upto: {
            category: 3,
            type: 4,
            name: 'Keep Upto',
            config_dat: {
                script: 'const { dataParser } = modules; dataParser.keepUpto($);'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        dtt_sub_string: {
            category: 3,
            type: 4,
            name: 'Sub String',
            config_dat: {
                script: 'const { dataParser } = modules; dataParser.subString($);'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        }
    },

    /*********************************/

    rp_record: {
        default_email_account: {
            type: 1,
            name: 'Default email account',
            config_dat: {
                user: 'demo@actionabl.ai',
                password: 'Kaizen@2',
                incoming_server: {
                    host: 'imappro.zoho.com',
                    port: 993,
                    protocol: 'imap',
                    ssl: true
                },
                outgoing_server: {
                    host: 'smtppro.zoho.com',
                    port: 465,
                    ssl: true
                }
            },
            can_override: true,
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        support_email_account: {
            type: 1,
            name: 'Support Email Account',
            config_dat: {
                user: 'support@actionabl.ai',
                password: 'Kaizen@2',
                incoming_server: {
                    host: 'imappro.zoho.com',
                    port: 993,
                    protocol: 'imap',
                    ssl: true
                },
                outgoing_server: {
                    host: 'smtppro.zoho.com',
                    port: 465,
                    ssl: true
                }
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        default_email_template: {
            type: 2,
            name: 'Default (blank) template',
            config_dat: {
                html_email: true,
                body_type: 'mailgen',
                body: {}
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        default_user_email_template: {
            type: 2,
            name: 'Default user template',
            config_dat: {
                email_subject: '<write subject here>',
                html_email: true,
                user_template: true,
                body_type: 'default',
                body: [
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'greetings',
                        greetings: 'Dear',
                        recipient_name: 'Member'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>write your message here...</p>'
                    }
                ]
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        forgot_password_email_template: {
            type: 2,
            name: 'Forgot password',
            config_dat: {
                email_subject: 'Reset your account password',
                html_email: true,
                body_type: 'mailgen',
                body: {
                    intro: 'You have requested to reset your Actionabl user password. If it was not you, ignore this e-mail.',
                    outro: 'The link expires in {{expiry_period}}, and can be used only once.',
                    action: {
                        instructions: 'To reset your password, click on the button below.',
                        button: {
                            text: 'Reset Password',
                            link: '{{reset_password_link}}'
                        }
                    }
                }
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        scheduled_report_email_template: {
            type: 2,
            name: 'Scheduled report',
            config_dat: {
                recipient_email: 'demo@actionabl.ai',
                email_subject: 'Scheduled Report: {{report_title}}',
                html_email: true,
                body_type: 'mailgen',
                body: {
                    recipient_name: 'All',
                    intro: 'Please see attached report.',
                    outro: 'You are receiving this email because you are subscribed to this scheduled report. Please contact system administrator to unsubscribe.'
                }
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        external_assignment_email_template: {
            type: 2,
            name: 'External assignment',
            config_dat: {
                email_subject: 'New user input task has been assigned to you',
                html_email: true,
                body_type: 'mailgen',
                body: {
                    recipient_name: 'there',
                    intro: 'New {{task_key}} task {{buss_id}} has been assigned to you.',
                    outro: "Should you need further help or have questions, please don't hesitate to contact us, we'd love to help.",
                    action: {
                        instructions: 'To complete this task, please click here:',
                        button: {
                            color: '#34c38f',
                            text: 'Task Detail',
                            link: 14
                        }
                    }
                }
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        task_notification_email_template: {
            type: 2,
            name: 'Task notification',
            config_dat: {
                recipient_email: 'demo@actionabl.ai',
                email_subject: 'New {{process_key}} - {{task_key}} task {{buss_id}} has been created.',
                html_email: true,
                body_type: 'default',
                body: [
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'plain_text',
                        text: 'Please login to the Actionabl to complete this task or click on link below.'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'link',
                        link_type: 'Button',
                        url: '{{TASK_NOTIFICATION_URL}}',
                        text: 'Click here to complete the task'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'plain_text',
                        skip_when: '$.error_message == null',
                        text: 'Error messages: \n{{error_message}}',
                        color: '#f46a6a'
                    }
                ]
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        task_notification_message_template: {
            type: 4,
            name: 'Task notification message',
            config_dat: {
                message: 'New {{process_key}} - {{task_key}} task {{buss_id}} has been created. Please login to the Actionabl to complete this task.'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        license_expiry_email_template: {
            type: 2,
            name: 'License expiry',
            config_dat: {
                email_subject: 'Actionabl license has expired.',
                html_email: true,
                body_type: 'mailgen',
                body: {
                    recipient_name: 'there',
                    intro: 'Actionabl license {{license_name}} has expired.',
                    outro: 'This is an automated message. Please do not reply to this email.'
                }
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        license_near_expiry_email_template: {
            type: 2,
            name: 'License near expiry',
            config_dat: {
                email_subject: 'Actionabl license expiring soon',
                html_email: true,
                body_type: 'mailgen',
                body: {
                    recipient_name: 'there',
                    intro: 'Actionabl license {{license_name}} is expiring in {{remainingDays}} days. Please renew at earliest to avoid any interruptions.',
                    outro: 'This is an automated message. Please do not reply to this email.'
                }
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        external_task_email_template: {
            type: 2,
            name: 'External Task',
            config_dat: {
                email_subject: 'Action Required: Additional Information Needed',
                html_email: true,
                body_type: 'default',
                body: [
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'greetings',
                        greetings: 'Dear',
                        recipient_name: 'Member'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>I hope this message finds you well. Thank you for choosing [Company Name] for your [product/service]. We are excited to work with you and are committed to ensuring the best experience possible.</p>\n<p>&nbsp;</p>\n<p>To proceed with your [product/service], we need some additional information from you. Could you please take a moment to fill out the necessary details via the link below?</p>'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'link',
                        link_type: 'Anchor',
                        text: 'Please click here to provide the additional information.',
                        url: '{{link}}'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>Your prompt response will help us to expedite the process and continue delivering our services without any delay. The form only takes a few minutes to complete.</p>\n<p>&nbsp;</p>\n<p>If you have any questions or need further assistance, feel free to contact us directly at [Department Email] or call us at [Company Phone Number].</p>\n<p>&nbsp;</p>\n<p>Thank you for your cooperation and looking forward to your swift response.</p>'
                    }
                ]
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        application_approval_email_template: {
            type: 2,
            name: 'Application Approval',
            config_dat: {
                email_subject: 'Your Application for [Product Name] Has Been Approved',
                html_email: true,
                body_type: 'default',
                body: [
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'greetings',
                        greetings: 'Dear',
                        recipient_name: 'Member'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>We are pleased to inform you that your application for the [Product Name] has been approved. Should you have any questions or require further assistance, please feel free to contact our customer service team.</p>\n<p>&nbsp;</p>\n<p>Thank you for choosing [Company Name]. We look forward to serving you with more of our products and services.</p>'
                    }
                ]
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        application_rejection_email_template: {
            type: 2,
            name: 'Application Rejection',
            config_dat: {
                email_subject: 'Update on Your Application for [Product Name]',
                html_email: true,
                body_type: 'default',
                body: [
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'greetings',
                        greetings: 'Dear',
                        recipient_name: 'Member'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>Thank you for your interest in our [Product Name]. After careful review of your application and account history, we regret to inform you that we are unable to approve your application at this time.</p>\n<p>&nbsp;</p>\n<p>Please be assured that this decision does not affect your existing accounts and services with us. For more information or to discuss other products that may suit your needs, please feel free to reach out to our customer support team.</p>\n<p>&nbsp;</p>\n<p>We value your relationship with [Company Name] and look forward to continuing to serve you.</p>'
                    }
                ]
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        access_code_email_template: {
            type: 2,
            name: 'Access Code',
            config_dat: {
                email_subject: 'Your Access code',
                html_email: true,
                body_type: 'default',
                body: [
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>Your access code is {{access_code}}. Enter online at prompt within 10 minutes. If you didn’t request this code, or encounter an issue with the code, please contact us.</p>'
                    }
                ]
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        thread_email_template: {
            type: 2,
            name: 'Thread email',
            config_dat: {
                email_subject: 'New thread message from [Company Name]',
                html_email: true,
                body_type: 'default',
                body: [
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'greetings',
                        greetings: 'Dear',
                        recipient_name: 'Member'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>{{msg}}</p>'
                    },
                    {
                        template: 'emailTemplateBuilder.js',
                        action: 'paragraph',
                        text: '<p>You can reply using the task link you received earlier or simply reply to this email.</p>\n<p>&nbsp;</p>\n<p>Thank you for your cooperation and looking forward to your swift response.</p>'
                    }
                ]
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        thread_message_template: {
            type: 4,
            name: 'Thread message',
            config_dat: {
                message: '{{msg}}. Please reply to this message to register your response.'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl'
        },
        git_service: {
            type: 5,
            name: 'Git',
            config_dat: {
                params: {
                    repository_type: {
                        type: 1,
                        value: 'Local'
                    },
                    remote_repository_path: {
                        type: 1,
                        value: 'https://github.com/Sarvesh-Renghe/bombus'
                    },
                    user_name: {
                        type: 1,
                        value: 'Bombus'
                    },
                    user_id: {
                        type: 1,
                        value: 'sarvesh.renghe@prescientinfotech.com'
                    },
                    password: {
                        type: 1,
                        value: 'Prescient#1'
                    }
                }
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        google_service: {
            type: 6,
            name: 'Google Service Account',
            config_dat: {
                service_type: 1,
                client_id: '66285412540-5hau7th8fj4tlq73pds75pr62uvftj11.apps.googleusercontent.com',
                client_password: 'yktXv9UwmB1ICnWIhH9rpg8y',
                sender_id: 66285412540,
                server_key: 'AAAAD27rILw:APA91bHWl85_DX9WU7_I8oSbSJ-qknjdfxrRweNKZfhXfrqFPQj8-2tX-etuqEkXMwWW1GAdRCzgG8ZlQ7IlrNWHdKv12BCBMzx-4temrON3bTIt0tMCtxLZcEmFvVLs-KUKlppbQoIj'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        microsoft_service: {
            type: 6,
            name: 'Microsoft Service Account',
            config_dat: {
                service_type: 2,
                client_id: '87c4f9e9-4a99-4ec8-8227-7543ecc1c5e3',
                client_password: 'C9g8Q~8If8YOAaF7he_O8WPlM2597uivMg7JQcG8'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        box_service: {
            type: 6,
            name: 'Box Service Account',
            config_dat: {
                service_type: 3,
                client_id: 'dcnw1urm27cegdc9wworimrae6rfjul4',
                client_password: 'yfQKxPxfq063okSnoqSvoeoMlLPIOP7l'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        dropbox_service: {
            type: 6,
            name: 'Dropbox Service Account',
            config_dat: {
                service_type: 4,
                client_id: 's72h0xh3sqmyecd',
                client_password: 'vex47k5vxnt8kk0'
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        google_service_full: {
            type: 7,
            name: 'Google Full Access',
            config_dat: {
                service_account: 'google_service',
                grant_type: 'refresh_token',
                google_drive: true,
                google_sheet: true,
                google_doc: true,
                google_mail: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        google_drive: {
            type: 7,
            name: 'Google Drive',
            config_dat: {
                service_account: 'google_service',
                grant_type: 'refresh_token',
                google_drive: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        google_drive_readonly: {
            type: 7,
            name: 'Google Drive Readonly',
            config_dat: {
                service_account: 'google_service',
                grant_type: 'refresh_token',
                google_drive_readonly: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        google_sheet: {
            type: 7,
            name: 'Google Sheet',
            config_dat: {
                service_account: 'google_service',
                grant_type: 'refresh_token',
                google_drive_readonly: true,
                google_sheet: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        google_doc: {
            type: 7,
            name: 'Google Doc',
            config_dat: {
                service_account: 'google_service',
                grant_type: 'refresh_token',
                google_drive_readonly: true,
                google_doc: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        google_mail: {
            type: 7,
            name: 'Google Mail',
            config_dat: {
                service_account: 'google_service',
                grant_type: 'refresh_token',
                google_mail: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        microsoft_service_full: {
            type: 7,
            name: 'Microsoft Full Access',
            config_dat: {
                service_account: 'microsoft_service',
                grant_type: 'refresh_token',
                offline_access: true,
                files_all: true,
                user_read: true,
                email_read_write: true,
                email_send: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        box_service_full: {
            type: 7,
            name: 'Box Full Access',
            config_dat: {
                service_account: 'box_service',
                grant_type: 'refresh_token',
                box: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        },
        dropbox_service_full: {
            type: 7,
            name: 'DropBox Full Access',
            config_dat: {
                service_account: 'dropbox_service',
                grant_type: 'refresh_token',
                dropbox: true
            },
            active: true,
            updated_at: 978287400000,
            updated_by: 'actionabl',
            readOnly: true
        }
    },

    /*********************************/

    rp_task_action: {
        send_mail: {
            type: 1,
            name: 'Send Mail',
            config_dat: {
                icon: 'Mail',
                email_template: 'default_user_email_template'
            },
            active: true,
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
        static_form_task: {
            type: 3,
            name: 'Static Form Task',
            config_dat: {
                icon: 'Web',
                email_template: 'default_user_email_template'
            },
            active: true,
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
        dynamic_form_task: {
            type: 4,
            name: 'Dynamic Form Task',
            config_dat: {
                icon: 'DisplaySettings',
                email_template: 'default_user_email_template'
            },
            active: true,
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
        start_thread: {
            type: 6,
            name: 'Start Thread',
            config_dat: {
                icon: 'Comment'
            },
            active: true,
            updated_at: 978325200000,
            updated_by: 'actionabl'
        },
    },

    /*********************************/

    rp_cron_schedule: {
        everyday_12am: {
            name: 'Everyday 12am',
            active: true,
            cron_config: [
                {
                    cron_expression: '0 0 * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        everyday_1am: {
            name: 'Everyday 1am',
            active: true,
            cron_config: [
                {
                    cron_expression: '0 1 * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        everyday_2am: {
            name: 'Everyday 2am',
            active: true,
            cron_config: [
                {
                    cron_expression: '0 2 * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        everyday_3am: {
            name: 'Everyday 3am',
            active: true,
            cron_config: [
                {
                    cron_expression: '0 3 * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        everyday_4am: {
            name: 'Everyday 4am',
            active: true,
            cron_config: [
                {
                    cron_expression: '0 4 * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        everyday_7pm: {
            name: 'Everyday 7pm',
            active: true,
            cron_config: [
                {
                    cron_expression: '0 19 * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        everyday_8pm: {
            name: 'Everyday 8pm',
            active: true,
            cron_config: [
                {
                    cron_expression: '0 20 * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        every_minute: {
            name: 'Every Minute',
            active: true,
            cron_config: [
                {
                    cron_expression: '* * * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        every_2minute: {
            name: 'Every 2 Minute',
            active: true,
            cron_config: [
                {
                    cron_expression: '*/2 * * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        },
        every_5minute: {
            name: 'Every 5 Minute',
            active: true,
            cron_config: [
                {
                    cron_expression: '*/5 * * * *'
                }
            ],
            updated_at: 978287400000,
            updated_by: 'actionabl',
        }
    },

    /*********************************/

    rp_ocr_cluster: {
        default: {
            config_dat: {},
            name: 'Default',
            file_type: 1,
            ocr_engine: 1,
            active: true,
            updated_at: 1651621731778,
            updated_by: 'actionabl'
        }
    }
};

module.exports = data;