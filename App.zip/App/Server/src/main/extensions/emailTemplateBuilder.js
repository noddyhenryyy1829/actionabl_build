const AsyncFunction = Object.getPrototypeOf(async function () { }).constructor;
const { config, constants, constants_r, GenericScriptBase, bfs, cacheService, util, Buff } = global.modules;
const { Jimp } = require('jimp');

const lookups = {
    font: ['Arial', 'Courier New', 'Georgia', 'Times New Roman', 'Trebuchet MS', 'Verdana', 'Calibri', 'Tahoma'],
    alignment: { left: 'Left', center: 'Center', right: 'Right' },
    link_type: ['Anchor', 'Button'],
    greetings: ['Hi', 'Dear'],
};

const tableStyles = {
    default: {
        label: 'Default',
        header_text: { 'background-color': '#EFF2F7' },
        th: {
            'font-weight': 500, padding: '12px 15px', 'text-align': 'center',
            'border-bottom': '2px solid #e0e0e0', 'border-top': '0px', 'border-left': '0px', 'border-right': '0px'
        },
        td: { padding: '12px 15px', 'text-align': 'center' }
    },
    bordered: {
        label: 'Bordered',
        header_text: { 'background-color': '#EFF2F7' },
        th: { 'font-weight': 500, padding: '12px 15px', 'text-align': 'center', border: '1px solid #e0e0e0' },
        td: { padding: '12px 15px', 'text-align': 'center', border: '1px solid #e0e0e0' }
    },
};

let tableStyleLookup = {};
for (let [id, val] of Object.entries(tableStyles)) {
    tableStyleLookup[id] = val.label;
}

class CustomScript extends GenericScriptBase {
    static get isMJML() {
        return config.email.use_mjml;
    }
    static get label() { return 'Standard'; }
    static get actions() {
        return {
            greetings: {
                label: 'Greetings',
                fields: {
                    greetings: { label: 'Greetings', field_attrs: { lookup: lookups.greetings } },
                    recipient_name: { label: 'Recipient Name' }
                },
                layout: [
                    [{ id: 'greetings', colSpan: 4 }, { id: 'recipient_name', colSpan: 8 }],
                ]
            },
            link: {
                label: 'Link',
                fields: {
                    link_type: { label: 'Type', field_attrs: { lookup: lookups.link_type } },
                    text: { label: 'Text' },
                    url: { label: 'URL', field_attrs: { freeSolo: true, lookup: constants_r.externalActionType } },
                    params: { label: 'Link Parameters' },
                    font: { label: 'Font', field_attrs: { lookup: lookups.font } },
                    font_size: { label: 'Font Size' },
                    color: { label: 'Color', fldTyp: constants.fieldDisplayType.Color },
                    background_color: { label: 'Background Color', fldTyp: constants.fieldDisplayType.Color },
                    alignment: { label: 'Alignment', field_attrs: { lookup: lookups.alignment } }
                },
                layout: [
                    [{ id: 'link_type', colSpan: 1 }, { id: 'text', colSpan: 3 }, { id: 'url', colSpan: 2 }, { id: 'params', colSpan: 6 }],
                    [
                        { id: 'font', colSpan: 3 }, { id: 'font_size', colSpan: 1 }, { id: 'alignment', colSpan: 2 },
                        { id: 'color', colSpan: 3 }, { id: 'background_color', colSpan: 3 }
                    ],
                ]
            },
            url: {
                label: 'URL',
                fields: {
                    url: { label: 'URL', field_attrs: { freeSolo: true, lookup: constants_r.externalActionType } },
                    params: { label: 'Link Parameters' },
                },
                layout: [
                    [{ id: 'url', colSpan: 5 }, { id: 'params', colSpan: 7 }]
                ]
            },
            paragraph: { label: 'Paragraph', display_type: 'html' },
            plain_text: {
                label: 'Text',
                fields: {
                    font: { label: 'Font', field_attrs: { lookup: lookups.font } },
                    font_size: { label: 'Font Size' },
                    color: { label: 'Color', fldTyp: constants.fieldDisplayType.Color },
                    background_color: { label: 'Background Color', fldTyp: constants.fieldDisplayType.Color },
                    text: { label: 'Text', width: '100%', field_attrs: { multiline: true, rows: 10, } },
                    alignment: { label: 'Alignment', field_attrs: { lookup: lookups.alignment } }
                },
                layout: [
                    [
                        { id: 'font', colSpan: 3 }, { id: 'font_size', colSpan: 1 }, { id: 'alignment', colSpan: 2 },
                        { id: 'color', colSpan: 3 }, { id: 'background_color', colSpan: 3 }
                    ],
                    [{ id: 'text', colSpan: 12 }],
                ]
            },
            image: {
                label: 'Image',
                fields: {
                    image: {
                        label: 'Image', fldTyp: constants.fieldDisplayType.FileSelect, field_attrs: { folderType: 'resource', folder: 'Templates/Email' }
                    },
                    width: { label: 'Width' },
                    height: { label: 'Height' },
                    alignment: { label: 'Alignment', field_attrs: { lookup: lookups.alignment } }
                },
                layout: [
                    [{ id: 'image', colSpan: 5 }, { id: 'width', colSpan: 1 }, { id: 'height', colSpan: 1 }, { id: 'alignment', colSpan: 5 }],
                ]
            },
            table: {
                label: 'Table',
                fields: {
                    header_text: { label: 'Table Header' },
                    rows: { label: 'Table Rows (field)' },
                    col_headers: { label: 'Column Headers' },
                    col_ids: { label: 'Fields Ids' },
                    table_style: { label: 'Style', field_attrs: { lookup: tableStyleLookup } },
                    alignment: { label: 'Alignment', field_attrs: { lookup: lookups.alignment } },
                    font: { label: 'Font', field_attrs: { lookup: lookups.font } },
                    font_size: { label: 'Font Size' },
                },
                layout: [
                    [{ id: 'header_text', colSpan: 2 }, { id: 'rows', colSpan: 2 }, { id: 'col_headers', colSpan: 4 }, { id: 'col_ids', colSpan: 4 }],
                    [{ id: 'font', colSpan: 4 }, { id: 'font_size', colSpan: 1 }, { id: 'alignment', colSpan: 3 }, { id: 'table_style', colSpan: 4 }],
                ]
            },
            section: {
                label: 'Section Template',
                fields: {
                    record_id: { label: 'Section Template Record', fldTyp: 'fldRecord', field_attrs: { type: constants.recordType.EmailTemplateSection } },
                },
                layout: [
                    [{ id: 'record_id', colSpan: 12 }],
                ]
            },
            custom: {
                label: 'Custom',
                fields: {
                    script: { label: 'Script', fldTyp: constants.fieldDisplayType.JavaScript },
                },
                layout: [
                    [{ id: 'script', colSpan: 12 }]
                ]
            },
        };
    }

    constructor() {
        super();
        let self = this;
        self.isMJML = config.email.use_mjml;
        self.defaultFont = { font: config.email.font, font_size: config.email.font_size };
    }

    skipSection($, emailData) {
        let { skip_when } = $;
        if (skip_when == null) return false;
        let result = util.evaluateExpression(skip_when, emailData);
        return result === true;
    }

    async greetings($, emailData) {
        let self = this;
        if (self.skipSection($, emailData)) return { rc: 0 };
        let { greetings, recipient_name } = $;
        greetings = greetings || 'Hi';
        if (recipient_name != null) {
            greetings += ' ' + recipient_name + ',';
        } else {
            greetings += ',';
        }
        return { rc: 0, data: { typ: 'mj-text', children: { typ: 'h3', text: greetings } } };
    }

    async link($, emailData) {
        let self = this;
        if (self.skipSection($, emailData)) return { rc: 0 };
        let { isMJML, defaultFont } = self;
        let { link_type, text, url, params, font, font_size, color, background_color, alignment } = $;
        if (font == null) font = defaultFont.font;
        if (font_size == null) font_size = defaultFont.font_size;
        if (color == null) color = 'white';
        if (background_color == null) background_color = '#556EE6';

        if (params != null) {
            params = params.trim();
            if (params == '') params = null;
        }

        if (params != null) {
            let rslt = util.parseJson(params);
            if (rslt.rc != 0) return { rc: 1, msg: `Invalid parameters ${params}` };
            params = rslt.data;
            params = Buff.toBase64(params);
            url = `${url}&params=${params}`;
        }

        let linkData;
        if (link_type == 'Button') {
            if (isMJML == true) {
                linkData = { typ: 'mj-button', attrs: { href: url, 'background-color': '#556EE6', color: 'white' }, text: text };
            } else {
                linkData = {
                    typ: 'div', attrs: { align: alignment || 'center' }, style: { 'margin': '10px' },
                    children: {
                        typ: 'table', attrs: { cellpadding: '0', cellspacing: '0', border: '0' }, children: {
                            typ: 'tr', children: {
                                typ: 'td', style: {
                                    'background-color': background_color, padding: '6px 20px', border: '1px solid gray',
                                    'font-family': font, 'font-size': font_size
                                },
                                children: {
                                    typ: 'a', attrs: { href: url, target: '_blank' }, children: text,
                                    style: { color: color, 'text-decoration': 'none', 'text-transform': 'none' },
                                }
                            }
                        }
                    }
                };
            }
        } else {
            linkData = { typ: 'mj-text', attrs: { align: 'center' }, children: { typ: 'a', text: text, attrs: { href: url } } };
        }
        return { rc: 0, data: linkData };
    }

    async url($, emailData) {
        let { url, params } = $;

        if (params != null) {
            params = params.trim();
            if (params == '') params = null;
        }

        if (params != null) {
            let rslt = util.parseJson(params);
            if (rslt.rc != 0) return { rc: 1, msg: `Invalid parameters ${params}` };
            params = rslt.data;
            params = Buff.toBase64(params);
            url = `${url}&params=${params}`;
        }
        return { rc: 0, data: url };
    }

    async paragraph($, emailData) {
        let self = this;
        if (self.skipSection($, emailData)) return { rc: 0 };
        let { isMJML } = self;

        let text = $.text;

        // Lexical adds p with br inside
        if (text != null && isMJML == true) {
            text = text.replaceAll('<br></p>', '</p>');
        }

        let ele = { html: text };
        if (isMJML == true) {
            ele = { typ: 'mj-text', skipReplaceNextLine: true, children: { html: text } };
        }

        return { rc: 0, data: ele };
    }

    async plain_text($, emailData) {
        let self = this;
        if (self.skipSection($, emailData)) return { rc: 0 };
        let { isMJML, defaultFont } = self;
        let { font, font_size, text, color, background_color, alignment } = $;
        if (font == null) font = defaultFont.font;
        if (font_size == null) font_size = defaultFont.font_size;

        if (text == null) return { rc: 0 };
        let ele;
        if (isMJML == true) {
            ele = { typ: 'mj-text', children: { html: text } };
        } else {
            let style = { 'font-family': font, 'font-size': font_size };
            if (color != null) style.color = color;
            if (background_color != null) style['background-color'] = background_color;
            if (alignment != null) style['text-align'] = alignment;
            text = text.replaceAll('\r\n', '<br>');
            text = text.replaceAll('\n', '<br>');
            ele = { typ: 'div', children: text, style };
        }

        return { rc: 0, data: ele };
    }

    async image($, emailData) {
        let self = this;
        if (self.skipSection($, emailData)) return { rc: 0 };
        let { image, width, height, alignment, folder } = $;
        let folderPath = config.folders.resources.published.templates.email.root;
        if (folder != null) folderPath = config.folders.resources.published.files.root + '/' + folder;
        let filePath = `${folderPath}/${image}`;
        let rslt = await bfs.readFileRaw(filePath);
        if (rslt.rc != 0) return rslt;
        let fileBytes = rslt.data;
        let base64 = Buffer.from(fileBytes).toString('base64');
        let extension = bfs.getExtension(filePath);
        let src = `data:image/${extension};base64,${base64}`;
        let ele = { typ: 'img', attrs: { src: src } };
        if (width == null && height == null) {
            try {
                let jimpImage = await Jimp.read(fileBytes);
                let bitmap = jimpImage.bitmap;
                width = bitmap.width;
                height = bitmap.height;
            } catch (err) {
                console.log(err.message);
            }
        }
        if (width != null || height != null) {
            let style = {};
            if (width != null) {
                style.width = width;
                ele.attrs.width = width;
            }
            if (height != null) {
                style.height = height;
                ele.attrs.height = height;
            }
            ele.style = style;
        }
        let style = { 'text-align': 'center' };
        if (alignment != null) style['text-align'] = alignment;
        return { rc: 0, data: { typ: 'div', style: style, children: ele } };
    }

    async table($, emailData) {
        let self = this;
        if (self.skipSection($, emailData)) return { rc: 0 };
        let { header_text, col_headers, col_ids, rows, alignment, font, font_size, table_style } = $;
        table_style = table_style || 'default';
        let tableStyle = tableStyles[table_style];

        rows = emailData[rows];
        if (rows == null) return { rc: 0, data: null };
        col_headers = col_headers.split(',');
        col_ids = col_ids.split(',');

        alignment = alignment || 'center';
        if (font == null) font = config.email.typography.font_family;
        if (font_size == null) font_size = config.email.typography.font_size;

        let attrs = { align: alignment };
        let fontStyle = { 'font-family': font, 'font-size': font_size };

        let trs = [];
        let tds = [];

        if (header_text != null) {
            tds.push({ typ: 'td', attrs: { colSpan: col_headers.length, align: 'center' }, text: header_text });
            trs.push({ typ: 'tr', style: tableStyle.header_text, children: tds });
        }

        tds = [];
        for (let col_header of col_headers) {
            col_header = col_header.trim();
            tds.push({ typ: 'th', style: tableStyle.th, text: col_header });
        }
        trs.push({ typ: 'tr', children: tds });

        for (let row of rows) {
            tds = [];
            for (let col_id of col_ids) {
                col_id = col_id.trim();
                tds.push({ typ: 'td', style: tableStyle.td, text: row[col_id] });
            }
            trs.push({ typ: 'tr', children: tds });
        }

        let table = { typ: 'table', children: trs, attrs: attrs, style: fontStyle };
        // let tableDiv = { typ: 'div', style: { 'overflow-x': 'auto', margin: '10px 0', width: '100%' }, children: table };
        let wrapperTable = {
            typ: 'table',
            attrs: { width: '100%', cellpadding: 0, cellspacing: 0, border: 0 },
            children: [
                {
                    typ: 'tr',
                    children: [
                        {
                            typ: 'td',
                            style: { 'padding': '10px 0' },
                            children: [
                                {
                                    typ: 'table',
                                    attrs: { cellpadding: 5, cellspacing: 0, border: 1 },
                                    style: { 'border-collapse': 'collapse', 'min-width': '500px' },
                                    children: table,
                                },
                            ],
                        },
                    ],
                },
            ],
        };

        return { rc: 0, data: wrapperTable };
    }

    async section($, emailData) {
        let self = this;
        if (self.skipSection($, emailData)) return { rc: 0 };
        let { record_id } = $;
        let rslt = await cacheService.getRecord(record_id);
        if (rslt.rc != 0) return rslt;
        if (rslt.data == null) return { rc: 1, msg: 'Missing record ' + record_id };
        let sections = rslt.data.config_dat.body;
        return { rc: 0, data: sections };
    }

    async custom($, emailData) {
        let self = this;
        let fnScript = `
        let self = this;
        ${$.script};
        `;
        let fn = new AsyncFunction('$', 'emailData', fnScript);
        fn = fn.bind(self);
        let rslt = await fn($, emailData);

        return rslt;
    }
}

module.exports = CustomScript;