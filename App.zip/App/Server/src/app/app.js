require('./modulesLoader');

// eslint-disable-next-line no-unused-vars -- logger needs to be loaded here
const { config, constants, logger, pm2 } = global.modules;
const { mode, server_id, env, host, http_port, https_port } = config.processArgs;

config.app.mode = (mode != null) ? mode : constants.appMode.Default;
config.app.server_id = (server_id != null) ? server_id : config.app.mode;
if (env != null) config.app.env = env;

// command line arguments take precedence over config files
const serverConfig = config.server[config.app.server_id] || { type: constants.appMode.Default };
if (host != null) serverConfig.host = host;
if (http_port != null) serverConfig.http_port = http_port;
if (https_port != null) serverConfig.https_port = https_port;

console.debug('app.processArgs:' + JSON.stringify(config.processArgs));
console.debug('Server mode: ' + config.app.mode);
console.debug('Environment: ' + config.app.env);

async function start() {
    if (config.app.mode != constants.appMode.Agent) {
        await global.modules.appServer.start(serverConfig);
    }

    if (config.app.mode == constants.appMode.Agent || config.app.mode == constants.appMode.AgentAssistant) {
        await global.modules.agentRoutes.start(serverConfig);
    }

    const restartSchedule = serverConfig.restart_schedule;
    const serverTitle = config.app.project_id + '_' + config.app.server_id;

    if (restartSchedule != null) {
        let job = {
            cron_schedule_id: restartSchedule,
            func: function () {
                global.modules.eventManager.createEvent(constants.appEvents.StopApp, true);
                console.debug(`App stop triggered to restart ${serverTitle} server...`);
                setTimeout(function () {
                    if (config.app.env == constants.envs.Prod) {
                        console.debug(`Restarting ${serverTitle} server...`);
                        pm2.restart(serverTitle).then(function (rslt) {
                            if (rslt && rslt.rc != 0) {
                                console.error('Restart failed with error: ' + rslt.msg);
                            }
                        }).catch(function (error) {
                            console.error('Restart failed with error: ' + error.message);
                        });
                    } else {
                        process.exit(99);
                    }
                }, 120000); // give 2 mins to complete running jobs
                return { rc: 0 };
            }
        };

        global.modules.cronProcessor.registerJob(false, serverTitle, job);
    }
}

start();
