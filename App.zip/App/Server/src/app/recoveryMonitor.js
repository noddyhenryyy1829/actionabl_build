const fs = require('fs');
const path = require('path');
const pm2 = require('pm2');
const { spawn, exec } = require('child_process');

require('./modulesLoader');

// eslint-disable-next-line no-unused-vars -- logger needs to be loaded here
const { config, logger, http } = global.modules;

const serviceConfig = {
    env: 'prod', mode: 'automation_server', server_id: 'automation_server_2'
};

let isRecoveryStarting = false;
let isRecoveryStopping = false;

function loadServiceConfig() {
    const { processArgs } = config;

    console.log('recovery monitor using project_path:', processArgs.project_path);

    serviceConfig.run_interval = config.jobs.recoveryMonitor.run_interval;
    if (processArgs.mode) serviceConfig.mode = processArgs.mode;
    if (processArgs.server_id) serviceConfig.server_id = processArgs.server_id;
    if (processArgs.project_path) serviceConfig.project_path = processArgs.project_path;

    serviceConfig.serverTitle = config.app.project_id + '_' + serviceConfig.server_id;

    // Find the main server configuration
    for (const server of Object.values(config.server)) {
        if (server.recovery_server == serviceConfig.server_id) {
            serviceConfig.mainServerConfig = server;
            break;
        }
    }

    if (serviceConfig.mainServerConfig == null) {
        console.log(`Server ${serviceConfig.server_id} is not configured as a recovery for any other server. Exiting...`);
        process.exit(1);
    }

    serviceConfig.home = config.folders.runtime.root + '/SystemAccount';
    if (!fs.existsSync(serviceConfig.home)) {
        fs.mkdirSync(serviceConfig.home, { recursive: true });
    }
}

function isRecoveryRunning() {
    return new Promise((resolve) => {
        exec('tasklist /FI "IMAGENAME eq node.exe" /FO CSV', (error, stdout) => {
            if (error) {
                resolve(false);
                return;
            }

            // Filter out processes that match node.exe
            const lines = stdout.split('\n');
            const nodeProcesses = lines.filter(line => line.includes('node.exe'));

            if (nodeProcesses.length > 1) {
                // Check command lines of node.exe processes for the actionabl flag
                exec('wmic process where "name=\'node.exe\'" get CommandLine /format:csv', (err, stdout2) => {
                    if (err) {
                        resolve(false);
                        return;
                    }

                    const recoveryRunning = stdout2.toLowerCase().includes(`--${serviceConfig.serverTitle}`);
                    resolve(recoveryRunning);
                });
            } else {
                resolve(false);
            }
        });
    });
}

function startRecoveryServer() {
    return new Promise((resolve, reject) => {
        console.log(`Starting recovery server ${serviceConfig.server_id}`);

        const args = {
            env: serviceConfig.env,
            mode: serviceConfig.mode,
            server_id: serviceConfig.server_id
        };

        if (serviceConfig.project_path) {
            args.project_path = serviceConfig.project_path;
        }

        const cwd = path.resolve(global.rootDir, '..');
        const recoveryService = spawn(
            'node', ['src\\app\\pm2Start.js', JSON.stringify(args)],
            {
                cwd, detached: true,
                env: {
                    ...process.env,
                    HOME: serviceConfig.home,
                    USERPROFILE: serviceConfig.home
                }
            }
        );

        // Detach from the parent and allow it to run independently
        recoveryService.unref();

        recoveryService.on('spawn', () => {
            console.log(`Node server ${serviceConfig.server_id} started in ${serviceConfig.mode} mode on pm2....`);
            isRecoveryStarting = true;
            resolve();
        });

        recoveryService.on('error', (error) => {
            console.error(`Error starting recovery server: ${error.message}`);
            isRecoveryStarting = false;
            reject(error);
        });

        recoveryService.on('exit', (code, signal) => {
            isRecoveryStarting = false;
            console.log(`PM2 launcher exited with code ${code}, signal ${signal}`);
            // The launcher process exits normally after starting PM2, this is expected
            if (code == 0) {
                console.log('PM2 launcher completed successfully - recovery server should now be running under PM2');
            } else if (isRecoveryStopping == false) {
                console.log('PM2 launcher failed, will attempt restart on next cycle');
            }
        });
    });
}

async function stopRecoveryServer() {
    console.log('Stopping recovery server running under PM2...');

    // Set environment variables needed by PM2
    process.env.HOME = serviceConfig.home;
    process.env.USERPROFILE = serviceConfig.home;

    try {
        let rslt = await new Promise((resolve) => {
            pm2.connect((err) => {
                if (err) resolve({ rc: 1, msg: err.message });
                else resolve({ rc: 0 });
            });
        });

        if (rslt.rc != 0) {
            console.log(`PM2 connect failed: ${rslt.msg}`);
            return;
        }

        rslt = await new Promise((resolve) => {
            pm2.delete(serviceConfig.serverTitle, (err) => {
                pm2.disconnect();
                if (err) resolve({ rc: 1, msg: err.message });
                else resolve({ rc: 0 });
            });
        });

        if (rslt.rc == 0) {
            console.log('Recovery server stopped successfully via PM2');
        } else {
            console.log(`PM2 stop failed: ${rslt.msg}`);
        }
    } catch (error) {
        console.error(`Error stopping recovery server via PM2: ${error.message}`);
    }
}

async function checkMainServer() {
    try {
        const rslt = await http.get({ url: serviceConfig.mainUrl, timeout: 5000, headers: { 'User-Agent': 'Actionabl Recovery Monitor' } });
        if (rslt.rc == 0 && rslt.http_cd == 200) {
            console.log('Main server is UP (HTTP 200).');
            return true;
        } else if (rslt.rc != 0) {
            if (rslt.err && rslt.err.code === 'ECONNREFUSED') {
                console.log(`Main server is DOWN. Connection refused: ${rslt.err.message}`);
            } else if (rslt.err && rslt.err.code === 'ETIMEDOUT') {
                console.log(`Main server is DOWN. Error: ${rslt.err.message}`);
            } else {
                console.log(`Main server is DOWN. HTTP Code: ${rslt.http_cd}, Message: ${rslt.msg}`);
            }
            return false;
        }
    } catch (error) {
        console.log(`Main server is DOWN. Reason: ${error.message}`);
        return false;
    }
}

async function monitoringLoop() {
    try {
        const isMainUp = await checkMainServer();
        const recoveryRunning = await isRecoveryRunning();

        if (isMainUp == false) {
            // Main server is down - check if recovery server is actually running
            if (recoveryRunning == false) {
                // Recovery server is not started it
                if (isRecoveryStarting == false) {
                    try {
                        await startRecoveryServer();
                    } catch (error) {
                        console.error(`Failed to start recovery server: ${error.message}`);
                    }
                } else {
                    console.log('PM2 launcher is still running...');
                }
            } else {
                console.log('Recovery server is already running under PM2.');
            }
        } else if (recoveryRunning == true) {
            // Main server is up - stop recovery server if it's running
            console.log('Main server is back up, stopping recovery server...');
            await stopRecoveryServer();
        }

    } catch (error) {
        console.error(`Monitoring cycle failed: ${error.message}`);
    } finally {
        setTimeout(monitoringLoop, serviceConfig.run_interval);
    }
}

async function gracefulShutdown(signal) {
    console.log(`Received ${signal}, shutting down gracefully...`);
    isRecoveryStopping = true;

    const recoveryRunning = await isRecoveryRunning();
    if (recoveryRunning == true) {
        await stopRecoveryServer();
    }

    console.log('Shutdown complete.');
    process.exit(0);
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function start() {
    sleep(3000);
    loadServiceConfig();

    // Extract base URL with port only (strip path)
    const urlParts = serviceConfig.mainServerConfig.url.split('/');
    serviceConfig.mainUrl = urlParts.slice(0, 3).join('/');

    console.log(`Monitoring main server at ${serviceConfig.mainUrl}`);

    monitoringLoop();
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

console.log('Starting Actionabl Recovery Monitor...');
start().catch((error) => {
    console.error(`Fatal error in recovery monitor: ${error.message}`);
    process.exit(1);
});