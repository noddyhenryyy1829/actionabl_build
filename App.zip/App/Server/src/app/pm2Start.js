require('./modulesLoader');

// eslint-disable-next-line no-unused-vars -- logger needs to be loaded here
const { config, constants, logger, pm2 } = global.modules;
const { mode, server_id } = config.processArgs;

config.app.mode = (mode != null) ? mode : constants.appMode.Default;
config.app.server_id = (server_id != null) ? server_id : config.app.mode;

const serverConfig = config.server[config.app.server_id] || {};
const serverTitle = config.app.project_id + '_' + config.app.server_id;

async function startPM2() {
    const options = {
        script: 'src/app/app.js',
        name: serverTitle,
        max_restarts: 10, // number of consecutive unstable restarts
        restart_delay: 30000, // time to wait before restarting a crashed app
        min_uptime: '1m', // min uptime of the app to be considered started
        out_file: '/dev/null', // no output log file for console.log
        error_file: config.folders.runtime.logs.pm2 + '/' + serverTitle + '-error.log'
    };

    if (serverConfig.cpus != null && serverConfig.cpus != 1) {
        options.instances = serverConfig.cpus;
        options.exec_mode = 'cluster';
    }

    if (serverConfig.memory_allocation != null) {
        options.node_args = '--max_old_space_size=' + serverConfig.memory_allocation;
        //options.max_memory_restart = (serverConfig.memory_allocation - 20) + 'M';
    } else {
        //options.max_memory_restart = (512 - 20) + 'M';
    }

    const args = [`--${serverTitle}`];
    for (const [key, val] of Object.entries(config.processArgs)) {
        args.push(key + '="' + val + '"');
    }
    if (args.length > 0) {
        options.args = args.join(' --');
    }

    const rslt = await pm2.start(options);
    if (rslt.rc != 0) {
        console.error(rslt.msg);
        setTimeout(function () { process.exit(1); }, 50);
    }
}

startPM2().catch(err => {
    console.error('PM2 start failed:', err);
    process.exit(1);
});