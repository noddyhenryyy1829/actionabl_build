const path = require('path');
require('./modulesLoader');

// eslint-disable-next-line no-unused-vars
const { logger, config, constants, util, pm2 } = global.modules;

let processArgs = {};
if (process.argv.length > 2) {
    try {
        let rslt = util.parseJson(process.argv[2]);
        if (rslt.rc == 0) processArgs = rslt.data;
    } catch (error) {
        console.error(error);
    }
}

let moduleType = processArgs.typ || 'grpc_server';
let spaceId = processArgs.space_id || '';
let serverId = 'python_' + moduleType;
if (spaceId != '') serverId += '_' + spaceId;
let serverConfig = {};

let workingDir = (processArgs.typ == 'space') ? '/../../../Python/spaces' : '/../../../Python';
workingDir = path.resolve(__dirname + workingDir).split('\\').join('/');
let pythonInterpreter = path.join(workingDir, spaceId, 'python_modules/Scripts/python.exe');
let pythonScript = path.resolve(__dirname + '/../../../Python/src/app/StartModule.py').split('\\').join('/');

async function startPM2() {
    let options = {
        cwd: workingDir,
        interpreter: pythonInterpreter,
        script: pythonScript,
        name: serverId,
        max_restarts: 10, // number of consecutive unstable restarts
        restart_delay: 30000, // time to wait before restarting a crashed app
        min_uptime: '1m', // min uptime of the app to be considered started
        out_file: config.folders.runtime.logs.python + '/python_server.log',
        error_file: config.folders.runtime.logs.python + '/python_server.log'
    };

    if (serverConfig.cpus != null && serverConfig.cpus != 1) {
        options.instances = serverConfig.cpus;
        options.exec_mode = 'cluster';
    }

    if (serverConfig.memory_allocation != null) {
        options.node_args = '--max_old_space_size=' + serverConfig.memory_allocation;
        //options.max_memory_restart = (serverConfig.memory_allocation - 20) + 'M';
    } else {
        //options.max_memory_restart = (512 - 20) + 'M';
    }

    if (process.argv.length > 2) {
        let args = [];
        for (let [key, val] of Object.entries(processArgs)) {
            args.push('-' + key + ' ' + val);
        }
        options.args = args.join(' ');
    }

    let rslt = await pm2.start(options);
    if (rslt.rc != 0) {
        console.error(rslt.msg);
        setTimeout(function () { process.exit(1); }, 50);
    }
}

startPM2();