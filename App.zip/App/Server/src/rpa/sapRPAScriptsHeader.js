let promiseData = null;
let rslt;
async function runSection(section, vals) {
    let rslt = await instance.runSection(section, vals);
    return rslt;
}

async function setFocus(id) {
    let rslt = await instance.appDriver.setFocus(id);
    return rslt;
}

async function press(id) {
    let rslt = await instance.appDriver.press(id);
    return rslt;
}

async function sendKey(id, key) {
    let rslt = await instance.appDriver.sendKey(id, key);
    return rslt;
}

async function sendCommand(cmd) {
    let rslt = await instance.appDriver.sendCommand(cmd);
    return rslt;
}

async function getValue(id) {
    let rslt = await instance.appDriver.getValue(id);
    return rslt;
}

async function setValue(id, value) {
    let rslt = await instance.appDriver.setValue(id, value);
    return rslt;
}

async function setSelected(id, value) {
    let rslt = await instance.appDriver.setSelected(id, value);
    return rslt;
}

async function wait(ms) {
    return instance.wait(ms);
}

async function mainFunctions($, ele) {
    let fns = [];
    try { if (startup != null) fns.push(startup); } catch (err) { }
    try { if (main != null) fns.push(main); } catch (err) { }
    try { if (reset != null) fns.push(reset); } catch (err) { }
    try { if (tearDown != null) fns.push(tearDown); } catch (err) { }

    for (let fn of fns) {
        let rslt = { rc: 0 };
        try {
            rslt = await fn($, ele);
        } catch (err) {
            rslt = { rc: 1, msg: { message: err.message, stack: err.stack } };
        }
    }
    if (promiseData != null) promiseData.clientResolve();
    return rslt;
}
