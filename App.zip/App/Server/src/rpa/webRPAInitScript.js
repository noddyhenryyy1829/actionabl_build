/* eslint-disable no-inner-declarations */

const actionablApi = function () {
    console.log('Adding actionablApi');

    let valueMap = {};
    let api = { referenceMap: {} };

    let attrs = [
        'accept', 'accesskey', 'action', 'alt', 'autocomplete', 'autocapitalize', 'autofocus',
        'checked', 'cols', 'colspan', 'disabled', 'draggable', 'for', 'form', 'formaction',
        'hidden', 'href', 'id', 'max', 'maxlength', 'method', 'name', 'onsubmit', 'placeholder',
        'readonly', 'required', 'role', 'rows', 'rowspan', 'selected', 'size', 'span', 'src',
        'style', 'tabindex', 'target', 'title', 'value', 'width', 'wrap'
    ];

    function getElementMap() {
        if (document.body == null) {
            return { rc: 1, msg: 'Document body not found' };
        }
        try {
            let actionablId = 1;

            function append(node, eMap) {
                let elements = [];

                if (node.shadowRoot) {
                    append(node.shadowRoot, eMap);
                }

                let children = node.children || [];
                for (let i = 0; i < children.length; i++) {
                    let e = children[i];
                    let se = new ShadowElement(e);

                    // Skip script and style
                    if (!se.type || se.type === 'script' || se.type === 'style') continue;

                    // Skip invisible elements
                    let styles = window.getComputedStyle(e);
                    if (styles.display === 'none' || styles.visibility === 'hidden') {
                        continue;
                    }

                    // Skip empty divs
                    if (se.type === 'div' && !e.children.length && !se.str.trim() && !Object.keys(se.attr || {}).length) {
                        continue;
                    }

                    actionablId++;
                    if (typeof e.setAttribute === 'function') {
                        e.setAttribute('data-actionabl-id', String(actionablId));
                    }
                    let ele = getShadowElementInfo(se);
                    ele.actionablId = se.actionablId;
                    ele.idx = i;

                    append(e, ele);
                    elements.push(ele);
                }

                if (elements.length > 0) {
                    eMap.children = eMap.children || [];
                    eMap.children.push(...elements);
                }
            }

            let eleMap = { type: 'body', actionablId: actionablId };
            let e = document.body;
            let se = new ShadowElement(e);
            let clientRect = se.clientRect;
            if (Object.keys(clientRect).length > 0) {
                eleMap.x = clientRect.x;
                eleMap.y = clientRect.y;
                eleMap.width = clientRect.width;
                eleMap.height = clientRect.height;
            }
            append(e, eleMap);

            let data = JSON.stringify(eleMap);
            return { rc: 0, data: data };
        } catch (err) {
            logError(err);
            return { rc: 1, msg: err.message };
        }
    }

    function getElementInfo(e) {
        let se = new ShadowElement(e);
        return getShadowElementInfo(se);
    }

    function getShadowElementInfo(se) {
        let e = se.e;
        let ele = { type: se.type };

        for (let attr of attrs) {
            let attrVal = se[attr];
            if (typeof attrVal === 'string' && (attrVal.trim() === '' || attrVal.length > 255)) {
                attrVal = null;
            }
            if (attrVal != null) {
                ele[attr] = attrVal;
            }
        }

        if (e.style != null && !isNaN(e.style.zIndex) && e.style.zIndex > 0) {
            ele.zIndex = Number(e.style.zIndex);
        }

        let classList = se.classList;
        if (classList.length > 0) ele.classList = classList;
        if (se.subType != null) ele.subType = se.subType;
        if (se.str != '') ele.str = se.str;

        let clientRect = se.clientRect;
        if (Object.keys(clientRect).length > 0) {
            ele.x = clientRect.x;
            ele.y = clientRect.y;
            ele.width = clientRect.width;
            ele.height = clientRect.height;
        }

        return ele;
    }

    function setValueMap(map) {
        valueMap = map;
    }

    function buildCondition(selector) {
        try {
            let fnStr;
            if (typeof selector === 'object' || (typeof selector === 'string' && selector[0] == '{')) {
                let map;
                if (typeof selector === 'object') {
                    map = selector;
                } else {
                    try {
                        map = JSON.parse(selector);
                    } catch (_) {
                        let fn = new Function('$', 'return ' + selector + ';');
                        map = fn(valueMap);
                    }
                }

                for (let [attr, val] of Object.entries(map)) {
                    let cond;
                    if (attr == 'matches') {
                        cond = 'e.' + attr + '(' + JSON.stringify(val) + ')';
                    } else if (attr == 'class') {
                        val = val.trim().replace(/\s+/g, '.');
                        val = '.' + val;
                        cond = 'e.matches(' + JSON.stringify(val) + ')';
                    } else if (attr == 'hasParent' || attr == 'hasChild') {
                        cond = 'se.' + attr + '(' + JSON.stringify(val) + ')';
                    } else {
                        if (attr.startsWith('idx')) val = val - 1;
                        let parts = attr.split('_');
                        let startMatch = '==';
                        let endMatch = '';
                        val = val.split("'").join("\\'");
                        cond = 'se.' + attr + startMatch + "'" + val + "'" + endMatch;
                        if (parts.length > 1) {
                            if (['trim'].includes(parts[1])) {
                                attr = attr.replaceAll('_', '.');
                                cond = 'se.' + attr + "() == '" + val + "'";
                            } else if (['includes', 'startsWith', 'endsWith'].includes(parts[1])) {
                                attr = attr.replaceAll('_', '.');
                                startMatch = '(';
                                endMatch = ')';
                                cond = 'se.' + attr + startMatch + "'" + val + "'" + endMatch;
                            } else if (['lt', 'gt', 'lte', 'gte'].includes(parts[1])) {
                                attr = parts[0];
                                let operator = ' < ';
                                if (parts[1] == 'gt') operator = ' > ';
                                if (parts[1] == 'lte') operator = ' <= ';
                                if (parts[1] == 'gte') operator = ' >= ';
                                cond = 'se.' + attr + operator + val;
                            }
                        }

                    }
                    if (fnStr == null) {
                        fnStr = cond;
                    } else {
                        fnStr += ' && ' + cond;
                    }
                }
            } else {
                fnStr = selector;
            }
            fnStr = 'return (' + fnStr + ');\r\n';
            fnStr = 'let se = new actionablApi.ShadowElement(e);\r\n' + fnStr;
            let func = new Function('e', '$', fnStr);
            return func;
        } catch (err) {
            logError(err);
        }
    }

    function applyCondition(root, selector) {
        // eslint-disable-next-line no-undef
        let isRootDoc = root instanceof Document;
        if (isRootDoc == true && api.scopeElement != null) {
            root = api.scopeElement;
        }
        let $ = valueMap || {};
        let arr = [];
        let matchFunc = buildCondition(selector);
        let eles = root.querySelectorAll('*');
        eles = Array.from(eles);
        if (isRootDoc == false) {
            try {
                if (matchFunc(root, $) == true) arr.push(root);
            } catch (err) {
                logError(err);
            }
        }
        for (let ele of eles) {
            try {
                if (matchFunc(ele, $) == true) arr.push(ele);
            } catch (err) {
                logError(err);
            }
        }

        return arr;
    }

    function getChildElements(parent) {
        let elements;
        let eles = parent.children;
        if (eles == null) eles = [];
        for (let i = 0; i < eles.length; i++) {
            let e = eles[i];
            let tagName = (e.tagName || '').toLowerCase();
            if (tagName == '' || tagName == 'script' || tagName == 'style') continue;
            if (elements == null) elements = [];
            elements.push(e);
        }
        return elements;
    }

    function applyRelation(e, selector) {
        let arr = [];
        let parts = selector.split(',');
        for (let i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim();
        }

        let relation = parts[0];
        relation = relation.toLowerCase();

        if (relation == 'parent' || relation == 'ancestor') {
            let lvl = 1;
            if (parts.length > 1) lvl = Number(parts[1]);
            let ele = getAncestor(e, lvl);
            if (ele != null) arr.push(ele);
        } else if (relation == 'child') {
            let idx;
            if (parts.length > 1) idx = Number(parts[1]) - 1;
            let list = getChildElements(e);
            if (list != null) {
                if (idx == null) {
                    arr.push(...list);
                } else {
                    arr.push(list[idx]);
                }
            }
        } else if (relation == 'sibling') {
            let idx;
            if (parts.length > 1) idx = Number(parts[1]);
            let list = getSibling(e, idx);
            if (list != null) {
                if (Array.isArray(list)) {
                    arr.push(...list);
                } else {
                    arr.push(list);
                }
            }
        } else if (relation == 'descendent') {
            let idx, lvl = 1;
            if (parts.length > 1) lvl = Number(parts[1]);
            if (parts.length > 2) idx = Number(parts[2]) - 1;

            let descNodes = getChildrenElements(e, lvl, 1);
            if (descNodes != null) {
                if (idx == null) {
                    arr.push(...descNodes);
                } else {
                    arr.push(descNodes[idx]);
                }
            }
        } else {
            let ele = e;
            let rules = [];
            for (let char of selector) {
                if (char == 'p' || char == 'c' || char == 's') {
                    rules.push([char, '']);
                } else if (char == '-' || (char >= '0' && char <= '9')) {
                    let rule = rules[rules.length - 1];
                    rule[1] = rule[1] + char;
                }
            }

            for (let rule of rules) {
                let ruleType = rule[0];
                let idx;
                if (rule[1] != '') idx = Number(rule[1]);
                if (idx == null) idx = 1;
                if (ruleType == 'p') {
                    ele = getAncestor(ele, idx);
                    if (ele == null) return [];
                } else if (ruleType == 'c') {
                    let list = getChildElements(ele);
                    if (list == null) return [];
                    ele = list[idx - 1];
                    if (ele == null) return [];
                } else if (ruleType == 's') {
                    ele = getSibling(ele, idx);
                    if (ele == null) return [];
                }
            }
            if (ele != null) arr.push(ele);
        }
        return arr;
    }

    function getSibling(e, idx) {
        let list = getChildElements(e.parentNode);
        if (list == null) return null;
        let pos = list.indexOf(e);
        if (idx && (pos + idx >= list.length || pos + idx < 0)) return null;
        if (idx != null) {
            return list[pos + idx];
        } else {
            list.splice(pos, 1);
            return list;
        }
    }

    function getAncestor(e, lvl) {
        for (let i = 0; i < lvl; i++) {
            e = e.parentNode;
            if (e == null) break;
        }
        return e;
    }

    function getChildrenElements(e, lvl, startLevel) {
        let childArray = [];
        let children = e.children;
        if (lvl == startLevel && children != null) {
            if (children.length <= 0) return null;
            return children;
        }
        if (children == null) return;
        let element;
        for (let i = 0; i < children.length; i++) {
            element = children[i];
            let retArray = getChildrenElements(element, lvl, startLevel + 1);
            if (retArray != null && retArray.length > 0) childArray.push(...retArray);
        }
        return childArray;
    }

    function elementHasChild(e, selector) {
        let matchFunc = buildCondition(selector);
        let childNodes = e.children;
        if (childNodes == null) return false;
        for (let ele of childNodes) {
            try {
                if (matchFunc(ele) == true) return true;
            } catch (err) {
                logError(err);
            }
        }
        return false;
    }

    function elementHasParent(e, selector) {
        let matchFunc = buildCondition(selector);
        let ele = e.parentNode;
        if (ele == null) return false;
        try {
            if (matchFunc(ele) == true) return true;
        } catch (err) {
            logError(err);
        }
        return false;
    }

    function logError(err) {
        console.error('actionablApi - Error ' + err.message);
        console.error('actionablApi - ErrorStack ' + err.stack);
    }

    function getElementProperties(e) {
        let se = new ShadowElement(e);
        return se.getProperties();
    }

    function getInnerHTML() {
        if (document.body == null) {
            return null;
        }
        return document.body.innerHTML;
    }

    class ShadowElement {
        constructor(e) {
            this.e = e;
        }

        attr(name) {
            let e = this.e;
            if (e.getAttribute == null) return null;
            return e.getAttribute(name);
        }

        get type() {
            let e = this.e;
            let tagName = e.tagName;
            if (tagName == null) return null;
            return tagName.toLowerCase();
        }

        get subType() {
            return this.attr('type');
        }

        get actionablId() {
            return this.attr('data-actionabl-id');
        }

        get classList() {
            let arr = this.attr('class');
            if (arr == null) return [];
            return arr.split(' ').filter(c => c.trim() !== '');
        }

        get str() {
            let e = this.e;
            let val = '';
            if (e.tagName == 'INPUT') {
                val = e.hasAttribute('value') ? e.getAttribute('value') : '';
            } else {
                let childNodes = e.childNodes;
                if (childNodes != null && childNodes.length > 0) {
                    val = [];
                    for (let node of childNodes) {
                        let vl;
                        if (node.nodeType == 3) {
                            vl = node.data;
                        } else {
                            vl = node.nodeValue;
                        }
                        if (typeof vl == 'string' && vl != null) {
                            val.push(vl);
                        }
                    }
                    val = val.join(' ');
                }
            }
            if (val == null) return '';
            return val.trim();
        }

        hasChild(selector) {
            return elementHasChild(this.e, selector);
        }

        hasParent(selector) {
            return elementHasParent(this.e, selector);
        }

        get idx() {
            let e = this.e;
            let parentNode = e.parentNode;
            let childNodes = parentNode.children;
            if (childNodes == null) return -1;
            childNodes = Array.from(childNodes);
            return childNodes.indexOf(e);
        }

        get pos() {
            let indx = this.idx;
            if (indx == -1) return indx;
            return indx + 1;
        }

        get clientRect() {
            let e = this.e;
            if (e.getBoundingClientRect) {
                let clientRect = e.getBoundingClientRect();
                if (clientRect != null) {
                    return { x: Math.round(clientRect.x), y: Math.round(clientRect.y), width: Math.round(clientRect.width), height: Math.round(clientRect.height) };
                }
            }
            return {};
        }

        get label() {
            let e = this.e;
            let eles = document.querySelectorAll('label');
            for (let ele of eles) {
                let labelFor = ele.getAttribute('for');
                if (labelFor == e.id) {
                    let se = new ShadowElement(ele);
                    return se.str;
                }
            }
            return null;
        }

        get x() { return this.clientRect.x; }
        get y() { return this.clientRect.y; }
        get width() { return this.clientRect.width; }
        get height() { return this.clientRect.height; }

        get accept() { return this.attr('accept'); }
        get accesskey() { return this.attr('accesskey'); }
        get action() { return this.attr('action'); }
        get alt() { return this.attr('alt'); }
        get autocomplete() { return this.attr('autocomplete'); }
        get autocapitalize() { return this.attr('autocapitalize'); }
        get autofocus() { return this.attr('autofocus'); }
        get checked() { return this.attr('checked'); }
        get class() { return this.attr('class'); }
        get cols() { return this.attr('cols'); }
        get colspan() { return this.attr('colspan'); }
        get disabled() { return this.attr('disabled'); }
        get draggable() { return this.attr('draggable'); }
        get for() { return this.attr('for'); }
        get form() { return this.attr('form'); }
        get formaction() { return this.attr('formaction'); }
        get hidden() { return this.attr('hidden'); }
        get href() { return this.attr('href'); }
        get id() { return this.attr('id'); }
        get max() { return this.attr('max'); }
        get maxlength() { return this.attr('maxlength'); }
        get method() { return this.attr('method'); }
        get name() { return this.attr('name'); }
        get onsubmit() { return this.attr('onsubmit'); }
        get placeholder() { return this.attr('placeholder'); }
        get readonly() { return this.attr('readonly'); }
        get required() { return this.attr('required'); }
        get role() { return this.attr('role'); }
        get rows() { return this.attr('rows'); }
        get rowspan() { return this.attr('rowspan'); }
        get selected() { return this.attr('selected'); }
        get size() { return this.attr('size'); }
        get span() { return this.attr('span'); }
        get src() { return this.attr('src'); }
        get style() { return this.attr('style'); }
        get tabindex() { return this.attr('tabindex'); }
        get target() { return this.attr('target'); }
        get title() { return this.attr('title'); }
        get value() { return this.attr('value'); }
        get wrap() { return this.attr('wrap'); }

        getProperties() {
            let arr = ['baseURI', 'value', 'size', 'x', 'y', 'width', 'height'];
            let e = this.e;
            let map = {};

            for (let key of arr) {
                let val = e[key];
                if (val != null) {
                    map[key] = val;
                }
            }

            map.clientRect = this.clientRect;
            return map;
        }

        getComputedStyle(styleName) {
            let e = this.e;
            let styles = window.getComputedStyle(e);
            let val = styles.getPropertyValue(styleName);
            return val;
        }

        getAllAttributes() {
            let e = this.e;
            let attrs = e.attributes;
            let len = attrs.length;
            let map = {};
            for (let i = 0; i < len; i++) {
                let item = attrs.item(i);
                let name = item.name;
                let val = item.value;
                if (val == null) continue;
                map[name] = val;
            }
            return JSON.stringify(map);
        }
    }

    function mutationObserverStart() {
        const body = document.body;
        const config = { attributes: true, childList: true, subtree: true };

        function onChange(mutationsList, observer) {
            for (const mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    console.log('A child node has been added or removed.');
                } else if (mutation.type === 'attributes') {
                    console.log('The ' + mutation.attributeName + ' attribute was modified.');
                }
            }
        }
        mutationObserverStop();
        // eslint-disable-next-line no-undef
        api.observer = new MutationObserver(onChange);
        api.observer.observe(body, config);
    }

    function mutationObserverStop() {
        if (api.observer != null) {
            api.observer.disconnect();
            api.observer = null;
        }
    }

    api.getElementMap = getElementMap;
    api.getElementInfo = getElementInfo;
    api.setValueMap = setValueMap;
    api.applyCondition = applyCondition;
    api.applyRelation = applyRelation;
    api.getElementProperties = getElementProperties;
    api.getInnerHTML = getInnerHTML;
    api.ShadowElement = ShadowElement;
    api.mutationObserverStart = mutationObserverStart;
    api.mutationObserverStop = mutationObserverStop;

    return api;
}();

window.actionablApi = actionablApi;