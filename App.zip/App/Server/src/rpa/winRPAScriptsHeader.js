let promiseData = null;
let rslt;
async function runSection(section, vals, selector) {
    return instance.runSection(section, vals, selector);
}

async function click(params) {
    let rslt = await instance.appDriver.click(params);
    return rslt;
}

async function doubleClick(params) {
    let rslt = await instance.appDriver.doubleClick(params);
    return rslt;
}

async function invoke(params) {
    let rslt = await instance.appDriver.invoke(params);
    return rslt;
}

async function select(params) {
    let rslt = await instance.appDriver.select(params);
    return rslt;
}

async function expand(params) {
    let rslt = await instance.appDriver.expand(params);
    return rslt;
}

async function findElement(params) {
    let rslt = await instance.appDriver.findElement(params);
    return rslt;
}

async function setValue(params) {
    let rslt = await instance.appDriver.setValue(params);
    return rslt;
}

async function navigateToChild(params) {
    let rslt = await instance.appDriver.navigateToChild(params);
    return rslt;
}

async function wait(ms) {
    return instance.wait(ms);
}
