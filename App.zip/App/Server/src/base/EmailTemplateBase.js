const { config, ImplBase } = global.modules;

class EmailTemplateBase extends ImplBase {
    async init(params) {
        let self = this;
        let data = params.data || {};
        self.emailData = data.emailData;
        self.template = data.template.body || {};

        if (config.mailgen != null) {
            self.product = config.mailgen.product;
        }

        self.widgets = [];
        return { rc: 0 };
    }

    async process() {
        return { rc: 1, msg: 'process must be implemented' };
    }

    addWidget(widget) {
        let self = this;
        self.widgets.push(widget);
    }

    buildGreetings() {
        let self = this;
        let { greeting, recipient_name } = self.template;
        let greetings = greeting || 'Hi';
        if (recipient_name != null) {
            greetings += ' ' + recipient_name + ',';
        } else {
            greetings += ',';
        }
        self.addWidget({ typ: 'h3', text: greetings });
    }

    buildIntro() {
        let self = this;
        let { intro } = self.template;
        if (intro == null) return;

        let ele = [];
        for (let txt of intro) {
            ele.push({ typ: 'div', text: txt.value });
        }

        self.addWidget({ typ: 'div', style: 'margin-bottom: 25px;', children: ele });
    }

    buildOutro() {
        let self = this;
        let { outro } = self.template;
        if (outro == null) return;

        let ele = [];
        for (let txt of outro) {
            ele.push({ typ: 'div', text: txt.value });
        }

        self.addWidget({ typ: 'div', style: 'margin-bottom: 25px;', children: ele });
    }

    buildAction() {
        let self = this;
        let { action } = self.template;
        if (action == null) return;
        let { instructions, button } = action;

        let btnStyle = 'padding: 3px 20px 3px 20px; border-radius: 3px; color: #ffffff; font-size: 15px; text-align: center; text-decoration: none; background-color: ' + button.color + ';';
        let ele = [
            { typ: 'span', text: instructions },
            { typ: 'a', text: button.text, style: btnStyle, attrs: { href: button.link } }
        ];

        ele = { typ: 'a', text: instructions, attrs: { href: button.link } };
        self.addWidget({ typ: 'div', style: 'margin-top: 25px; margin-bottom: 25px;', children: ele });
    }

    buildTable() {
        let self = this;
        let { table_title, table } = self.template;
        if (table == null || table.data == null || table.data.length == 0) return;
        let tableData = table.data;
        let firstRow = tableData[0];
        let colNames = Object.keys(firstRow);

        let trs = [];
        let tds = [];
        let tdStyle = 'border: 1px dotted #a0a0a0; font-family: Helvetica, Arial;';

        if (table_title != null) {
            tds.push({ typ: 'td', attrs: { colSpan: colNames.length }, style: tdStyle + ' text-align: center; font-weight: bold; font-size: 1.1em; padding: 2px;', text: table_title });
            trs.push({ typ: 'tr', children: tds });
        }

        tds = [];
        for (let colName of colNames) {
            tds.push({ typ: 'td', style: tdStyle, text: self.toTitleCase(colName) });
        }
        trs.push({ typ: 'tr', children: tds });
        for (let row of tableData) {
            tds = [];
            for (let colName of colNames) {
                tds.push({ typ: 'td', style: tdStyle + ' font-size: .8em;', text: row[colName] });
            }
            trs.push({ typ: 'tr', children: tds });
        }
        self.addWidget({ typ: 'table', style: 'margin-bottom: 10px; width: 100%; border-collapse: collapse;', children: trs });
    }

    buildTable2(tableTitle, tableRows) {
        let self = this;
        let colNames = tableRows[0];

        let trs = [];
        let tds = [];
        let tdStyle = 'border: 1px dotted #a0a0a0; font-family: Helvetica, Arial;';

        if (tableTitle != null) {
            tds.push({ typ: 'td', attrs: { colSpan: colNames.length }, style: tdStyle + ' text-align: center; font-weight: bold; font-size: 1.1em; padding: 2px;', text: tableTitle });
            trs.push({ typ: 'tr', children: tds });
        }

        tds = [];
        for (let colName of colNames) {
            tds.push({ typ: 'td', style: tdStyle, text: self.toTitleCase(colName) });
        }
        trs.push({ typ: 'tr', children: tds });
        for (let i = 1; i < tableRows.length; i++) {
            let tableRow = tableRows[i];
            tds = [];
            for (let cell of tableRow) {
                tds.push({ typ: 'td', style: tdStyle + ' font-size: .8em;', text: cell });
            }
            trs.push({ typ: 'tr', children: tds });
        }
        self.addWidget({ typ: 'table', style: 'margin-bottom: 10px; width: 100%; border-collapse: collapse;', children: trs });
    }

    buildSignature() {
        let self = this;
        let { signature } = self.template;
        if (signature == null) return;

        self.addWidget({ typ: 'div', text: signature });
        if (self.product != null) {
            self.addWidget({ typ: 'div', text: self.product.name });
        }
    }

    buildCopyright() {
        let self = this;
        if (self.product == null || self.product.link == null) return;
        let txt = '&copy; ' + new Date().getFullYear() + ' <a href="' + self.product.link + '" target="_blank">' + self.product.name + '</a>. All rights reserved.';
        self.addWidget({ typ: 'div', style: 'text-align: center; margin-top: 10px;font-size: 10px; color: #808080;', text: txt });
    }

    buildHtml() {
        let self = this;
        let lines = [
            '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',
            '<html xmlns="http://www.w3.org/1999/xhtml">',
            '<head>',
            '<meta name="viewport" content="width=device-width, initial-scale=1.0" />',
            '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />',
            '</head>',
            '<body style="height: 100%; width: calc(100% - 20px); margin: 10px; background-color: #f5f5f5; color: #303030; font-family: Helvetica, Arial;">',
        ];

        let lns = self.buildWidgets();
        lines.push(...lns);

        lines.push('</body>');
        return lines.join('\r\n');
    }

    buildWidgets() {
        let self = this;
        let lines = [];
        for (let widget of self.widgets) {
            if (widget == null) continue;
            let lns = self.buildWidget(widget);
            lines.push(...lns);
        }
        return lines;
    }

    buildWidget(widget) {
        let self = this;
        let lines = [];

        if (widget.html != null) {
            return [widget.html];
        }

        let startLine = '<' + widget.typ;
        if (widget.attrs != null) {
            for (let [id, val] of Object.entries(widget.attrs)) {
                startLine += ' ' + id + '="' + val + '"';
            }
        }

        if (widget.style != null) {
            startLine += ' style="' + widget.style + '"';
        }

        startLine += '>';

        if (widget.children != null) {
            lines.push(startLine);
            if (Array.isArray(widget.children)) {
                for (let child of widget.children) {
                    let childLines = self.buildWidget(child);
                    lines.push(...childLines);
                }
            } else {
                let childLines = self.buildWidget(widget.children);
                lines.push(...childLines);
            }
            lines.push('</' + widget.typ + '>');
        } else {
            let line = startLine + widget.text + '</' + widget.typ + '>';
            lines.push(line);
        }
        return lines;
    }

    toTitleCase(str) {
        str = str.split('_').join(' ');
        return str.replace(
            /\w\S*/g,
            function (txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            }
        );
    }
}

module.exports = EmailTemplateBase;