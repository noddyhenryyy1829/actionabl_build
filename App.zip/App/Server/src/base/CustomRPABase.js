const { RPABase } = global.modules;

class CustomRPABase extends RPABase {
    async init(params) {
        let self = this;
        self.rpaParams = params.rpaParams || {};
        self.$ = params.data || {};
        return { rc: 0 };
    }
}

module.exports = CustomRPABase;