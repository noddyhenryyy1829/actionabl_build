const { ImplBase } = global.modules;

class OCRScriptBase extends ImplBase {
    async init(params) {
        let self = this;
        self.data = params.data || {};
        self.scriptParams = params.scriptParams || {};
        return { rc: 0 };
    }

    async process() {
        return { rc: 1, msg: 'process must be implemented' };
    }
}

module.exports = OCRScriptBase;