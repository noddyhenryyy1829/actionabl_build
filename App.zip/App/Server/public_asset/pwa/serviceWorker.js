/* eslint-disable no-undef */
self.addEventListener('install', function (event) {
    console.log('service-worker installed');
});

self.addEventListener('activate', function (event) {
    console.log('service-worker activated');
    return self.clients.claim();
});

self.addEventListener('push', function (event) {
    if (event.data == null) return;

    let title = 'Actionabl';
    let options = { icon: 'pwa/icon.svg', badge: 'pwa/favicon.ico' };
    let data = event.data.text();

    if (data.startsWith('{')) {
        data = event.data.json();
        options.body = data.body;
        if (data.title != null) title = data.title;
        if (data.proc_id != null) options.data = { proc_id: data.proc_id };
    } else {
        options.body = data;
    }

    event.waitUntil(
        self.registration.showNotification(title, options).catch(function(error) {
            console.error('service-worker push error:', error);
        })
    );
});

self.addEventListener('notificationclick', function (event) {
    event.notification.close();
    const options = event.notification.data || {};

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clientList) {
            // Check if any client matches the desired hostname pattern
            for (let i = 0; i < clientList.length; i++) {
                let client = clientList[i];
                let clientUrl = new URL(client.url);
                if (clientUrl.hostname.endsWith('actionabl.ai') && 'focus' in client) {
                    // Send a message to the client to open a task
                    if (options.proc_id != null) {
                        client.postMessage({ type: 'open_task', proc_id: options.proc_id });
                    }
                    // Set focus on the client
                    return client.focus();
                }
            }
            // If no matching client found, open a new window
            if (clients.openWindow) {
                return clients.openWindow('https://cloud.actionabl.ai');
            }
        }).catch(function(error) {
            console.error('service-worker notificationclick error:', error);
        })
    );
});