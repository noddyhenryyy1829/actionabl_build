const searchParams = new URLSearchParams(window.location.search);
let params = {};
for (let [key, val] of searchParams.entries()) {
    params[key] = val;
}

let manifestMap = {
    default: {
        short_name: 'Actionabl',
        name: 'Actionabl',
        icons: [{ src: 'icon.svg', type: 'image/svg' }],
    },
    chartway: {
        short_name: 'Chartway BO',
        name: 'Chartway BO',
        icons: [{ src: 'chartway_icon.svg', type: 'image/svg' }],
    },
};

let iOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
for (let [id, val] of Object.entries(manifestMap)) {
    val.display = 'standalone';
    val.theme_color = '#333';
    val.background_color = '#ffffff';
    if (iOS == true) {
        val.start_url = '.';
    }
}

let manifestData = manifestMap[params.org || 'default'];
let stringManifest = JSON.stringify(manifestData, null, 2);
const blob = new Blob([stringManifest], { type: 'application/json' });
const manifestURL = URL.createObjectURL(blob);
document.querySelector('#manifest_placeholder').setAttribute('href', manifestURL);
if (params.org == 'chartway') {
    document.querySelector('#icon_placeholder').setAttribute('href', 'public_asset/pwa/chartway_icon.svg');
}